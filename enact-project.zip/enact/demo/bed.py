"""Generic synthesized music bed for a reel of any length (numpy only).
  python3 demo/bed.py <seconds> <out.wav>
Techno-ish: minor pads + bass, soft kick/hat pulse, rising arp, reverb tail.
"""
import sys
import wave
from pathlib import Path

import numpy as np

DUR = float(sys.argv[1]) if len(sys.argv) > 1 else 28.0
OUT = sys.argv[2] if len(sys.argv) > 2 else "demo/build/bed.wav"
SR = 48000
N = int(SR * DUR)
t = np.arange(N) / SR
out = np.zeros((N, 2))
rng = np.random.default_rng(42)
hz = lambda n: 440 * 2 ** ((n - 69) / 12)


def add(sig, at, pan=0.5, gain=1.0):
    s = int(at * SR)
    if s < 0:
        sig = sig[-s:]; s = 0
    e = min(N, s + len(sig))
    if s >= N or e <= s:
        return
    seg = sig[: e - s] * gain
    out[s:e, 0] += seg * (1 - pan); out[s:e, 1] += seg * pan


def tone(note, dur, det=0.0, harm=(1, 0.3, 0.12)):
    tt = np.arange(int(SR * dur)) / SR
    f = hz(note) * 2 ** (det / 1200)
    return sum(h * np.sin(2 * np.pi * f * k * tt) for k, h in enumerate(harm, 1))


def pad(note, dur):
    s = tone(note, dur, 6) + tone(note, dur, -6)
    env = np.clip(np.arange(len(s)) / (SR * 0.6), 0, 1) * np.clip((len(s) - np.arange(len(s))) / (SR * 0.8), 0, 1)
    return s * env


def blip(note, dur=0.2):
    tt = np.arange(int(SR * dur)) / SR
    return (np.sin(2 * np.pi * hz(note) * tt) + 0.5 * np.sin(4 * np.pi * hz(note) * tt)) * np.exp(-tt * 18)


def kick(dur=0.22):
    tt = np.arange(int(SR * dur)) / SR
    return np.sin(2 * np.pi * (120 * np.exp(-tt * 22) + 45) * tt) * np.exp(-tt * 9)


def hat(dur=0.05):
    tt = np.arange(int(SR * dur)) / SR
    return rng.standard_normal(len(tt)) * np.exp(-tt * 90) * 0.5


CH = [[45, 48, 52, 57], [41, 45, 48, 53], [36, 40, 43, 48], [43, 47, 50, 55]]
bar = DUR / 4
for i, ch in enumerate(CH):
    for j, n in enumerate(ch):
        add(pad(n, bar + 1.2), i * bar - 0.2, 0.5 + 0.18 * np.sin(i + j), 0.055 / (1 + j * 0.25))
    add(pad(ch[0] - 12, bar + 1.0), i * bar, 0.5, 0.07)

beat = 0.5
tc = DUR * 0.18
while tc < DUR - 2:
    sw = np.clip((tc - DUR * 0.18) / 3, 0.25, 1) * np.clip((DUR - 2 - tc) / 3, 0.25, 1)
    add(kick(), tc, 0.5, 0.5 * sw); add(hat(), tc + beat / 2, 0.6, 0.18 * sw)
    tc += beat

tc, m = DUR * 0.28, 0
while tc < DUR - 2:
    ch = CH[min(3, int(tc // bar))]; n = ch[m % 4] + 12 * (1 + (m // 8) % 2)
    add(blip(n, 0.22), tc, 0.5 + 0.3 * np.sin(m * 1.3), 0.05 * np.clip((tc - DUR * 0.28) / 2, 0.2, 1))
    m += 1; tc += 0.25

# gentle resolve near the end
add(sum(pad(n, 3.0) for n in [48, 55, 60, 64]), DUR - 4, 0.5, 0.05)

wet = np.zeros_like(out)
for dly, g in ((0.13, .3), (0.27, .2), (0.41, .13), (0.6, .08)):
    s = int(dly * SR); wet[s:] += out[:-s] * g
out += wet
out *= (np.clip(t / 1.0, 0, 1) * np.clip((DUR - t) / 2.5, 0, 1))[:, None]
out /= max(1e-6, np.abs(out).max()); out *= 0.68

p = Path(OUT); p.parent.mkdir(parents=True, exist_ok=True)
with wave.open(str(p), "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((out * 32767).astype("<i2").tobytes())
print(OUT)
