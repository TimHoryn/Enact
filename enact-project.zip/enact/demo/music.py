"""Synthesized cyber/techno bed for the spyscan reel — numpy only, no samples.
python3 demo/music.py  ->  demo/build/music.wav
Timings line up with the scene beats in demo.html.
"""
import wave
from pathlib import Path

import numpy as np

SR, DUR = 48000, 32.5
N = int(SR * DUR)
t = np.arange(N) / SR
out = np.zeros((N, 2))
rng = np.random.default_rng(42)

hz = lambda n: 440 * 2 ** ((n - 69) / 12)


def add(sig, at, pan=0.5, gain=1.0):
    s = int(at * SR)
    if s < 0:
        sig = sig[-s:]
        s = 0
    e = min(N, s + len(sig))
    if s >= N or e <= s:
        return
    seg = sig[: e - s] * gain
    out[s:e, 0] += seg * (1 - pan)
    out[s:e, 1] += seg * pan


def tone(note, dur, detune=0.0, harm=(1, 0.3, 0.12)):
    tt = np.arange(int(SR * dur)) / SR
    f = hz(note) * 2 ** (detune / 1200)
    w = sum(h * np.sin(2 * np.pi * f * k * tt) for k, h in enumerate(harm, 1))
    return w


def pad(note, dur):
    s = tone(note, dur, 6) + tone(note, dur, -6)
    env = np.clip(np.arange(len(s)) / (SR * 0.6), 0, 1)
    env *= np.clip((len(s) - np.arange(len(s))) / (SR * 0.8), 0, 1)
    return s * env


def blip(note, dur=0.12):
    tt = np.arange(int(SR * dur)) / SR
    w = np.sin(2 * np.pi * hz(note) * tt) + 0.5 * np.sin(2 * np.pi * hz(note) * 2 * tt)
    return w * np.exp(-tt * 18)


def click(dur=0.04, f=1800):
    tt = np.arange(int(SR * dur)) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.5 * rng.standard_normal(len(tt))) * np.exp(-tt * 60)


def chime(root, dur=1.4):
    s = np.zeros(int(SR * dur))
    for k, n in enumerate([root, root + 7, root + 12, root + 16]):
        s += blip(n, dur) * np.exp(-k * 0.3)
    return s


def kick(dur=0.22):
    tt = np.arange(int(SR * dur)) / SR
    f = 120 * np.exp(-tt * 22) + 45
    return np.sin(2 * np.pi * f * tt) * np.exp(-tt * 9)


def hat(dur=0.05):
    tt = np.arange(int(SR * dur)) / SR
    return rng.standard_normal(len(tt)) * np.exp(-tt * 90) * 0.5


# --- chord bed: A minor loop (Am - F - C - G), low and detuned ---
CH = [[45, 48, 52, 57], [41, 45, 48, 53], [36, 40, 43, 48], [43, 47, 50, 55]]
bar = DUR / 4
for i, ch in enumerate(CH):
    for j, n in enumerate(ch):
        add(pad(n, bar + 1.2), i * bar - 0.2, pan=0.5 + 0.18 * np.sin(i + j), gain=0.055 / (1 + j * 0.25))
    add(pad(ch[0] - 12, bar + 1.0), i * bar, pan=0.5, gain=0.07)  # bass root

# --- pulse: kick on beats + hat offbeats (120 BPM) from 7.6s on ---
beat = 0.5
k = 0
tcur = 7.0
while tcur < 30.5:
    swell = np.clip((tcur - 7.0) / 3, 0.25, 1) * np.clip((31.5 - tcur) / 3, 0.25, 1)
    add(kick(), tcur, 0.5, 0.5 * swell)
    add(hat(), tcur + beat / 2, 0.6, 0.18 * swell)
    k += 1
    tcur += beat

# --- arp: 16th-note blips following the chords, 13s..24s (rising energy) ---
tcur, s16 = 8.0, 0.25
m = 0
while tcur < 30.0:
    ch = CH[min(3, int(tcur // bar))]
    n = ch[m % 4] + 12 * (1 + (m // 8) % 2)
    g = 0.05 * np.clip((tcur - 8) / 2, 0.2, 1)
    add(blip(n, 0.22), tcur, 0.5 + 0.3 * np.sin(m * 1.3), g)
    m += 1
    tcur += s16

# --- SFX tied to scene events ---
for i in range(8):            # typing (log in once)
    add(click(f=2200 + i * 60), 1.5 + i * 0.12, 0.45, 0.22)
add(chime(57), 2.7, 0.5, 0.45)                      # signed in
for i in range(3):            # cookies / tokens / auth captured
    add(blip(64 + i * 4, 0.18), 3.6 + i * 0.3, 0.35 + 0.15 * i, 0.14)
# mechanic: request flies, then 200 OK
add(np.sin(2*np.pi*np.linspace(240,1500,int(SR*0.5))*np.arange(int(SR*0.5))/SR)*np.exp(-np.arange(int(SR*0.5))/SR*4), 7.7, 0.5, 0.22)
add(chime(64, 1.2), 9.7, 0.5, 0.5)                  # 200 OK
add(blip(69, 0.2), 14.8, 0.5, 0.12)                 # key handoff
for i in range(4):            # power cards appear
    add(blip(60 + i * 3, 0.16), 19.1 + i * 0.8, 0.45, 0.12)
add(chime(60, 2.0), 28.4, 0.5, 0.5)                 # payoff logo
for n in [48, 55, 60, 64]:
    add(pad(n, 3.6), 28.5, 0.5, 0.06)

# --- reverb-ish tail ---
wet = np.zeros_like(out)
for dly, g in ((0.13, .3), (0.27, .2), (0.41, .13), (0.6, .08)):
    s = int(dly * SR)
    wet[s:] += out[:-s] * g
out += wet

# master
out *= (np.clip(t / 1.0, 0, 1) * np.clip((DUR - t) / 2.5, 0, 1))[:, None]
out /= max(1e-6, np.abs(out).max())
out *= 0.7

p = Path(__file__).with_name("build") / "music.wav"
p.parent.mkdir(exist_ok=True)
with wave.open(str(p), "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((out * 32767).astype("<i2").tobytes())
print(p)
