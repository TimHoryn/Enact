"""Render the spyscan reel frame-by-frame: headless Chromium -> JPEG frames -> ffmpeg (1080×1920, 60fps).
  python3 demo/render.py stills 1 6 10 16 22    — single frames (seconds) to demo/build/still-*.png
  python3 demo/render.py video                  — out/spyscan-demo.mp4 (audio from demo/build/music.wav if present)
The page supersamples internally (2× canvas), so we render at device_scale_factor=1.
"""
import os
import subprocess
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

DEMO = Path(__file__).resolve().parent
BUILD = DEMO / "build"; BUILD.mkdir(exist_ok=True)
OUT = DEMO.parent / "out"; OUT.mkdir(exist_ok=True)
# Which reel to render — set REEL=demo2.html REELOUT=spyscan-api REELAUDIO=music2.wav
PAGE = (DEMO / os.environ.get("REEL", "demo.html")).as_uri()
OUTNAME = os.environ.get("REELOUT", "spyscan-demo")
STILLPFX = os.environ.get("REELOUT", "still")
AUDIO = BUILD / os.environ.get("REELAUDIO", "music.wav")
mode = sys.argv[1] if len(sys.argv) > 1 else "video"

with sync_playwright() as pw:
    b = pw.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
    pg.on("pageerror", lambda e: print("pageerror:", e, file=sys.stderr))
    pg.goto(PAGE, wait_until="load")
    info = pg.evaluate("() => window.__ready")
    FPS, frames = int(info.get("fps", 60)), info["frames"]
    print(f"frames={frames} fps={FPS}", file=sys.stderr)

    if mode == "stills":
        # __frame(f) is deterministic/stateless — render each wanted frame directly.
        want = sorted(round(float(s) * FPS) for s in sys.argv[2:]) or [0]
        for f in want:
            pg.evaluate(f"window.__frame({f})")
            p = BUILD / f"{STILLPFX}-{f / FPS:05.1f}.png"
            pg.screenshot(path=str(p)); print(p)
    else:
        audio = AUDIO
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "image2pipe",
               "-framerate", str(FPS), "-c:v", "mjpeg", "-i", "-"]
        if audio.exists():
            cmd += ["-i", str(audio)]
        cmd += ["-vf", "scale=1080:1920:flags=lanczos,format=yuv420p", "-c:v", "libx264",
                "-preset", "medium", "-crf", "18", "-r", str(FPS), "-movflags", "+faststart"]
        if audio.exists():
            cmd += ["-c:a", "aac", "-b:a", "192k", "-shortest"]
        out_mp4 = str(OUT / f"{OUTNAME}.mp4")
        cmd += [out_mp4]
        enc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        t0 = time.time()
        for f in range(frames):
            pg.evaluate(f"window.__frame({f})")
            enc.stdin.write(pg.screenshot(type="jpeg", quality=92))
            if f % 120 == 0:
                print(f"{f}/{frames}  {time.time()-t0:.0f}s", file=sys.stderr, flush=True)
        enc.stdin.close(); enc.wait()
        print(out_mp4, f"{time.time()-t0:.0f}s")
    b.close()
