/* Shared design system for spyscan reels — premium glass + gradient mesh.
   Each reel HTML includes this, then defines its own scenes and calls register(). */
const W=1080,H=1920,SS=2,FPS=60;
const cv=document.getElementById('c');cv.width=W*SS;cv.height=H*SS;cv.style.width=W+'px';cv.style.height=H+'px';
const ctx=cv.getContext('2d');
const MONO='ui-monospace,"SF Mono",Menlo,Consolas,monospace',SANS='system-ui,-apple-system,"Segoe UI",Roboto,sans-serif';
const C={text:'#eef3fc',dim:'#8a98b2',blue:'#5b9dff',cyan:'#46e3c9',green:'#35d07f',coral:'#ff6b7a',amber:'#ffce6b',violet:'#9b7bff',line:'#22314d'};

function mb(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const rnd=mb(7);const STARS=Array.from({length:70},()=>({x:rnd()*W,y:rnd()*H,r:0.4+rnd()*1.5,sp:5+rnd()*16,ph:rnd()*6.28,a:0.1+rnd()*0.35}));
const GRAIN=(()=>{const n=document.createElement('canvas');n.width=n.height=180;const g=n.getContext('2d');const d=g.createImageData(180,180);for(let i=0;i<d.data.length;i+=4){const v=rnd()*255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=rnd()*26;}g.putImageData(d,0,0);return ctx.createPattern(n,'repeat');})();

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),ease=x=>x<0?0:x>1?1:x*x*(3-2*x),easeOut=x=>1-Math.pow(1-clamp(x,0,1),3),seg=(s,e,t)=>clamp((t-s)/(e-s),0,1);
const alpha=(s,e,t,f=0.5)=>Math.min(seg(s,s+f,t),1-seg(e-f,e,t));

function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function tx(s,x,y,sz,col,f=SANS,al='left',w=''){ctx.font=`${w} ${sz}px ${f}`;ctx.fillStyle=col;ctx.textAlign=al;ctx.textBaseline='alphabetic';ctx.fillText(s,x,y);}
function glow(cx,cy,r,col,a){ctx.save();const g=ctx.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');ctx.globalAlpha=a;ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r,0,7);ctx.fill();ctx.restore();}
function dot(x,y,r,col,a=1){ctx.save();ctx.globalAlpha=a;ctx.shadowColor=col;ctx.shadowBlur=r*2.4;ctx.fillStyle=col;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.restore();}
function gradText(s,cx,y,sz,c1,c2,w='800',f=SANS){ctx.font=`${w} ${sz}px ${f}`;const ww=ctx.measureText(s).width;const g=ctx.createLinearGradient(cx-ww/2,0,cx+ww/2,0);g.addColorStop(0,c1);g.addColorStop(1,c2);ctx.fillStyle=g;ctx.textAlign='center';ctx.fillText(s,cx,y);}
function heading(lines,cx,y,sz,a){ctx.save();ctx.globalAlpha=a;lines.forEach((l,i)=>tx(l,cx,y+i*(sz+10),sz,C.text,SANS,'center','800'));ctx.restore();}
function eyebrow(label,cx,y,col,a){ctx.save();ctx.globalAlpha=a;ctx.font=`700 26px ${MONO}`;const w=ctx.measureText(label).width;dot(cx-w/2-26,y-9,5,col,1);ctx.fillStyle=col;ctx.textAlign='left';ctx.fillText(label,cx-w/2,y);ctx.restore();}
function panel(x,y,w,h,tint=null){ctx.save();
  ctx.shadowColor='rgba(0,0,0,0.5)';ctx.shadowBlur=55;ctx.shadowOffsetY=22;rr(x,y,w,h,26);ctx.fillStyle='rgba(12,18,38,0.42)';ctx.fill();ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  const g=ctx.createLinearGradient(0,y,0,y+h);g.addColorStop(0,'rgba(255,255,255,0.12)');g.addColorStop(0.45,'rgba(255,255,255,0.045)');g.addColorStop(1,'rgba(255,255,255,0.02)');rr(x,y,w,h,26);ctx.fillStyle=g;ctx.fill();
  if(tint){glow(x+w*0.5,y+h*0.5,Math.max(w,h)*0.5,tint,0.14);}
  const b=ctx.createLinearGradient(0,y,0,y+h);b.addColorStop(0,'rgba(255,255,255,0.55)');b.addColorStop(0.5,'rgba(255,255,255,0.14)');b.addColorStop(1,'rgba(255,255,255,0.06)');ctx.strokeStyle=b;ctx.lineWidth=1.5;rr(x,y,w,h,26);ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,0.22)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x+26,y+1.5);ctx.lineTo(x+w-26,y+1.5);ctx.stroke();ctx.restore();}
function strokeS(col,w){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.lineCap='round';ctx.lineJoin='round';}

function icoLock(cx,cy,s,c){strokeS(c,s*0.08);const bw=s*0.7,bh=s*0.52;rr(cx-bw/2,cy-bh*0.05,bw,bh,s*0.1);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy-bh*0.05,bw*0.3,Math.PI,0);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy+bh*0.22,s*0.05,0,7);ctx.fillStyle=c;ctx.fill();}
function icoKey(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.arc(cx-s*0.16,cy,s*0.18,0,7);ctx.stroke();ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+s*0.32,cy);ctx.moveTo(cx+s*0.2,cy);ctx.lineTo(cx+s*0.2,cy+s*0.12);ctx.moveTo(cx+s*0.32,cy);ctx.lineTo(cx+s*0.32,cy+s*0.12);ctx.stroke();}
function icoCookie(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.arc(cx,cy,s*0.3,0,7);ctx.stroke();ctx.fillStyle=c;[[-0.08,-0.08],[0.1,-0.02],[0.02,0.12],[-0.12,0.08],[0.12,0.14]].forEach(p=>{ctx.beginPath();ctx.arc(cx+p[0]*s,cy+p[1]*s,s*0.035,0,7);ctx.fill();});}
function icoShield(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.moveTo(cx,cy-s*0.32);ctx.lineTo(cx+s*0.26,cy-s*0.2);ctx.lineTo(cx+s*0.26,cy+s*0.08);ctx.quadraticCurveTo(cx+s*0.26,cy+s*0.28,cx,cy+s*0.34);ctx.quadraticCurveTo(cx-s*0.26,cy+s*0.28,cx-s*0.26,cy+s*0.08);ctx.lineTo(cx-s*0.26,cy-s*0.2);ctx.closePath();ctx.stroke();strokeS(c,s*0.09);ctx.beginPath();ctx.moveTo(cx-s*0.1,cy);ctx.lineTo(cx-s*0.02,cy+s*0.09);ctx.lineTo(cx+s*0.12,cy-s*0.08);ctx.stroke();}
function icoRobot(cx,cy,s,c){strokeS(c,s*0.08);rr(cx-s*0.32,cy-s*0.2,s*0.64,s*0.48,s*0.12);ctx.stroke();ctx.beginPath();ctx.moveTo(cx,cy-s*0.2);ctx.lineTo(cx,cy-s*0.36);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy-s*0.4,s*0.05,0,7);ctx.fillStyle=c;ctx.fill();ctx.beginPath();ctx.arc(cx-s*0.12,cy,s*0.045,0,7);ctx.arc(cx+s*0.12,cy,s*0.045,0,7);ctx.fill();strokeS(c,s*0.06);ctx.beginPath();ctx.moveTo(cx-s*0.1,cy+s*0.13);ctx.lineTo(cx+s*0.1,cy+s*0.13);ctx.stroke();}
function icoGlobe(cx,cy,s,c){strokeS(c,s*0.07);ctx.beginPath();ctx.arc(cx,cy,s*0.3,0,7);ctx.stroke();ctx.beginPath();ctx.ellipse(cx,cy,s*0.13,s*0.3,0,0,7);ctx.stroke();ctx.beginPath();ctx.moveTo(cx-s*0.3,cy);ctx.lineTo(cx+s*0.3,cy);ctx.moveTo(cx-s*0.26,cy-s*0.15);ctx.lineTo(cx+s*0.26,cy-s*0.15);ctx.moveTo(cx-s*0.26,cy+s*0.15);ctx.lineTo(cx+s*0.26,cy+s*0.15);ctx.stroke();}
function icoGear(cx,cy,s,c){strokeS(c,s*0.08);const R=s*0.22;for(let i=0;i<8;i++){const an=i/8*6.283;ctx.beginPath();ctx.moveTo(cx+Math.cos(an)*R,cy+Math.sin(an)*R);ctx.lineTo(cx+Math.cos(an)*(R+s*0.1),cy+Math.sin(an)*(R+s*0.1));ctx.stroke();}ctx.beginPath();ctx.arc(cx,cy,R,0,7);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy,s*0.08,0,7);ctx.stroke();}
function icoForm(cx,cy,s,c){strokeS(c,s*0.08);rr(cx-s*0.3,cy-s*0.34,s*0.6,s*0.68,s*0.08);ctx.stroke();for(let i=0;i<3;i++){const yy=cy-s*0.2+i*s*0.2;rr(cx-s*0.2,yy,s*0.4,s*0.1,s*0.04);ctx.stroke();}}
function icoRepeat(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.arc(cx,cy,s*0.26,0.5,Math.PI*1.7);ctx.stroke();const ax=cx+Math.cos(0.5)*s*0.26,ay=cy+Math.sin(0.5)*s*0.26;ctx.beginPath();ctx.moveTo(ax-s*0.1,ay-s*0.02);ctx.lineTo(ax,ay);ctx.lineTo(ax+s*0.02,ay-s*0.12);ctx.stroke();}
function icoSheet(cx,cy,s,c){strokeS(c,s*0.08);rr(cx-s*0.3,cy-s*0.34,s*0.6,s*0.68,s*0.08);ctx.stroke();for(let i=1;i<4;i++){ctx.beginPath();ctx.moveTo(cx-s*0.22,cy-s*0.34+i*s*0.17);ctx.lineTo(cx+s*0.22,cy-s*0.34+i*s*0.17);ctx.stroke();}ctx.beginPath();ctx.moveTo(cx,cy-s*0.3);ctx.lineTo(cx,cy+s*0.3);ctx.stroke();}
function icoCheck(cx,cy,s,c){strokeS(c,s*0.13);ctx.beginPath();ctx.moveTo(cx-s*0.22,cy);ctx.lineTo(cx-s*0.05,cy+s*0.18);ctx.lineTo(cx+s*0.25,cy-s*0.2);ctx.stroke();}
function icoCross(cx,cy,s,c){strokeS(c,s*0.13);ctx.beginPath();ctx.moveTo(cx-s*0.18,cy-s*0.18);ctx.lineTo(cx+s*0.18,cy+s*0.18);ctx.moveTo(cx+s*0.18,cy-s*0.18);ctx.lineTo(cx-s*0.18,cy+s*0.18);ctx.stroke();}
function icoCode(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.moveTo(cx-s*0.1,cy-s*0.18);ctx.lineTo(cx-s*0.28,cy);ctx.lineTo(cx-s*0.1,cy+s*0.18);ctx.moveTo(cx+s*0.1,cy-s*0.18);ctx.lineTo(cx+s*0.28,cy);ctx.lineTo(cx+s*0.1,cy+s*0.18);ctx.stroke();}
function icoPlug(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.moveTo(cx,cy+s*0.3);ctx.lineTo(cx,cy+s*0.08);ctx.stroke();rr(cx-s*0.16,cy-s*0.16,s*0.32,s*0.24,s*0.06);ctx.stroke();ctx.beginPath();ctx.moveTo(cx-s*0.08,cy-s*0.16);ctx.lineTo(cx-s*0.08,cy-s*0.3);ctx.moveTo(cx+s*0.08,cy-s*0.16);ctx.lineTo(cx+s*0.08,cy-s*0.3);ctx.stroke();}
function icoRadar(cx,cy,s,c){strokeS(c,s*0.07);for(const rr0 of[0.12,0.22,0.3]){ctx.beginPath();ctx.arc(cx,cy,s*rr0,0,7);ctx.stroke();}ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+Math.cos(-0.6)*s*0.3,cy+Math.sin(-0.6)*s*0.3);ctx.stroke();dot(cx+s*0.16,cy-s*0.12,s*0.04,c,1);}
function icoBell(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.moveTo(cx-s*0.22,cy+s*0.12);ctx.quadraticCurveTo(cx-s*0.22,cy-s*0.22,cx,cy-s*0.26);ctx.quadraticCurveTo(cx+s*0.22,cy-s*0.22,cx+s*0.22,cy+s*0.12);ctx.closePath();ctx.stroke();ctx.beginPath();ctx.moveTo(cx-s*0.3,cy+s*0.12);ctx.lineTo(cx+s*0.3,cy+s*0.12);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy+s*0.2,s*0.05,0,7);ctx.fillStyle=c;ctx.fill();}
function icoClock(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.arc(cx,cy,s*0.3,0,7);ctx.stroke();ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx,cy-s*0.18);ctx.moveTo(cx,cy);ctx.lineTo(cx+s*0.14,cy+s*0.06);ctx.stroke();}
function icoEye(cx,cy,s,c){strokeS(c,s*0.08);ctx.beginPath();ctx.moveTo(cx-s*0.32,cy);ctx.quadraticCurveTo(cx,cy-s*0.26,cx+s*0.32,cy);ctx.quadraticCurveTo(cx,cy+s*0.26,cx-s*0.32,cy);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy,s*0.1,0,7);ctx.stroke();}

function chip(cx,cy,r,col,ico,a=1){ctx.save();ctx.globalAlpha=a;glow(cx,cy,r*2.3,col+'44',0.95);
  rr(cx-r,cy-r,2*r,2*r,r*0.42);const g=ctx.createLinearGradient(0,cy-r,0,cy+r);g.addColorStop(0,'rgba(255,255,255,0.15)');g.addColorStop(1,'rgba(255,255,255,0.03)');ctx.fillStyle=g;ctx.fill();
  rr(cx-r,cy-r,2*r,2*r,r*0.42);ctx.fillStyle='rgba(9,15,32,0.34)';ctx.fill();
  ctx.strokeStyle=col;ctx.lineWidth=2;rr(cx-r,cy-r,2*r,2*r,r*0.42);ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,0.32)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(cx-r+12,cy-r+1.5);ctx.lineTo(cx+r-12,cy-r+1.5);ctx.stroke();
  ico(cx,cy,r*1.5,col);ctx.restore();}
function tag(x,y,label,col){ctx.font=`600 24px ${MONO}`;const w=ctx.measureText(label).width+40;rr(x,y,w,42,10);ctx.fillStyle='rgba(13,24,44,0.95)';ctx.fill();ctx.strokeStyle=col;ctx.lineWidth=1.5;rr(x,y,w,42,10);ctx.stroke();dot(x+20,y+21,5,col,1);tx(label,x+34,y+28,24,C.text,MONO,'left');return w;}
function browser(x,y,w,h,url){panel(x,y,w,h);rr(x,y,w,52,24);ctx.fillStyle='rgba(30,44,74,0.7)';ctx.fill();['#ff5f57','#febc2e','#28c840'].forEach((c,i)=>dot(x+32+i*28,y+26,7,c,1));rr(x+120,y+13,w-150,26,13);ctx.fillStyle='rgba(8,14,30,0.8)';ctx.fill();tx('🔒 '+(url||'your-account.example'),x+140,y+31,21,C.dim,MONO,'left');}
// generic glass list row with an icon chip, title+sub, optional check / cross badge
function row(x,y,w,h,ico,col,title,sub,badge){panel(x,y,w,h,col);chip(x+h*0.62,y+h/2,h*0.33,col,ico,1);
  tx(title,x+h*1.15,y+h/2-8,36,C.text,SANS,'left','700');tx(sub,x+h*1.15,y+h/2+32,27,C.dim,SANS,'left');
  if(badge==='check')chip(x+w-h*0.44,y+h*0.34,h*0.15,C.green,icoCheck,1);
  if(badge==='cross')chip(x+w-h*0.44,y+h*0.34,h*0.15,C.coral,icoCross,1);}

function bg(t){
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#070a16');g.addColorStop(0.5,'#0a0f22');g.addColorStop(1,'#0b1328');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  const s1=Math.sin(t*0.3),s2=Math.cos(t*0.24);
  glow(W*0.16+s1*30,H*0.14,820,'rgba(124,92,255,0.55)',0.55);
  glow(W*0.9,H*0.08+s2*30,880,'rgba(79,140,255,0.5)',0.5);
  glow(W*0.08,H*0.74,860,'rgba(43,212,192,0.42)',0.42);
  glow(W*0.94,H*0.86+s1*24,820,'rgba(91,157,255,0.5)',0.46);
  glow(W*0.5,H*0.46,760,'rgba(70,120,255,0.3)',0.4);
  ctx.strokeStyle='rgba(120,160,230,0.045)';ctx.lineWidth=1;const gs=104,dy=(t*8)%gs;for(let x=0;x<=W;x+=gs){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}for(let y=-gs+dy;y<=H;y+=gs){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
  for(const s of STARS){const y=(s.y-t*s.sp)%H,yy=y<0?y+H:y;dot(s.x,yy,s.r,'#bcd4ff',s.a*(0.6+0.4*Math.sin(t+s.ph)));}
  ctx.save();ctx.globalAlpha=0.5;ctx.fillStyle=GRAIN;ctx.fillRect(0,0,W,H);ctx.restore();
  const v=ctx.createRadialGradient(W/2,H*0.46,H*0.2,W/2,H*0.5,H*0.82);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(2,4,10,0.62)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);
}
function register(frame,dur){window.__frame=(f)=>{const t=f/FPS;ctx.setTransform(SS,0,0,SS,0,0);ctx.clearRect(0,0,W,H);bg(t);frame(t);};window.__ready=Promise.resolve({frames:Math.round(dur*FPS)});}
