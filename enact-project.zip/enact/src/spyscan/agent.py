"""High-level, agent-friendly facade over a capture.

    from spyscan.agent import Spyscan
    with Spyscan.open("capture") as sp:
        sp.operations()                       # what can I call?
        r = sp.call("GET /cloud/v2/instances", page=2)
        rows = sp.collect("GET /cloud/v1/os-images/")
        sp.find("balance")                    # fuzzy search

Hides the browser/engine/storage plumbing and returns parsed, structured results.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any

from .agentkit import build_manifest
from .browser import BrowserSession
from .export import build_session_json, _shape
from .model import Session
from .replay import ReplayEngine
from .tasks import collect as _collect


@dataclass
class CallResult:
    status: int | None
    ok: bool
    data: Any = None          # parsed JSON when possible
    shape: str = ""
    raw: str | None = None
    dry_run: bool = False
    note: str = ""


@dataclass
class Spyscan:
    capture_dir: str
    session: Session
    manifest: dict
    browser: BrowserSession
    engine: ReplayEngine
    _ops: dict = field(default_factory=dict)  # "METHOD /path" -> op meta

    @classmethod
    def open(cls, capture_dir: str, headless: bool = True, allow_writes: bool = False) -> "Spyscan":
        session = Session.load(os.path.join(capture_dir, "session.har"))
        sj = os.path.join(capture_dir, "session.json")
        if os.path.exists(sj):
            with open(sj, encoding="utf-8") as fh:
                doc = json.load(fh)
        else:
            doc = build_session_json(session)
        manifest = build_manifest(doc)
        origin = session.entries[0].request.origin + "/" if session.entries else None
        storage = os.path.join(capture_dir, "storage_state.json")
        browser = BrowserSession(storage_state=storage if os.path.exists(storage) else None,
                                 headless=headless, start_url=origin).start()
        engine = ReplayEngine(browser, session, allow_writes=allow_writes)
        ops = {f"{o['method']} {o['path']}": o for o in manifest["operations"]}
        return cls(capture_dir, session, manifest, browser, engine, ops)

    # -- discovery ------------------------------------------------------------

    def operations(self) -> list[dict]:
        return self.manifest["operations"]

    def describe(self) -> dict:
        return {k: self.manifest[k] for k in ("site", "auth", "rules", "how_to_use")}

    def find(self, query: str, limit: int = 8) -> list[dict]:
        toks = [t for t in query.lower().split() if t]
        scored = []
        for op in self.manifest["operations"]:
            hay = f"{op['path']} {op.get('returns','')} {op.get('task','')}".lower()
            score = sum(hay.count(t) for t in toks)
            if score:
                scored.append((score, op))
        scored.sort(key=lambda x: -x[0])
        return [op for _, op in scored[:limit]]

    # -- action ---------------------------------------------------------------

    def _index(self, endpoint: str) -> int:
        method, _, path = endpoint.partition(" ")
        idx = next((e.index for e in self.session.entries
                    if e.request.method == method and e.request.path == path), None)
        if idx is None:
            raise ValueError(f"no such endpoint in the capture: {endpoint}")
        return idx

    def _edits(self, endpoint: str, params: dict) -> dict:
        op = self._ops.get(endpoint, {})
        where = {p["name"]: p.get("in", "query") for p in op.get("params", [])}
        is_write = op.get("is_write", endpoint.split(" ", 1)[0] in ("POST", "PUT", "PATCH", "DELETE"))
        q, b = {}, {}
        for k, v in params.items():
            dest = where.get(k) or ("body" if is_write else "query")
            (b if dest == "body" else q)[k] = v
        edits = {}
        if q:
            edits["query"] = q
        if b:
            edits["body"] = b
        return edits

    def call(self, endpoint: str, allow_writes: bool | None = None, **params) -> CallResult:
        idx = self._index(endpoint)
        res = self.engine.replay(idx, edits=self._edits(endpoint, params) or None,
                                 allow_writes=allow_writes)
        data = None
        if res.body:
            try:
                data = json.loads(res.body)
            except Exception:
                data = None
        return CallResult(
            status=res.status, ok=(res.status is not None and 200 <= res.status < 300),
            data=data, shape=_shape(data) if data is not None else "",
            raw=res.body, dry_run=res.dry_run, note=res.note,
        )

    def collect(self, endpoint: str, out: str | None = None, max_pages: int = 50) -> dict:
        r = _collect(self.engine, endpoint, out_path=out, max_pages=max_pages)
        return {"rows": r.rows, "pages": r.pages, "keys": r.keys, "sample": r.sample, "out": r.out}

    # -- lifecycle ------------------------------------------------------------

    def close(self) -> None:
        self.browser.stop()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
