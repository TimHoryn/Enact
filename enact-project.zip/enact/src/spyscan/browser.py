"""Live browser session: one real Chromium context used for both recording and
replay. Recording captures a HAR plus the storage state (cookies + localStorage)
and an optional user-action log. Replay restores that storage state into a real
context so every replayed request carries live cookies and an authentic
fingerprint — nothing is spoofed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from playwright.sync_api import sync_playwright

# Injected at document start to log user actions for action-level replay (tier 3).
_ACTION_LOGGER = """
(() => {
  function sel(el){
    if (!el || el === document) return 'document';
    if (el.id) return '#' + el.id;
    if (el.name) return el.tagName.toLowerCase() + '[name="' + el.name + '"]';
    return el.tagName ? el.tagName.toLowerCase() : 'unknown';
  }
  document.addEventListener('click', e => window.__spyact && window.__spyact({type:'click', selector: sel(e.target)}), true);
  document.addEventListener('submit', e => window.__spyact && window.__spyact({type:'submit', selector: sel(e.target)}), true);
  document.addEventListener('change', e => window.__spyact && window.__spyact({type:'fill', selector: sel(e.target), value: e.target.value}), true);
})();
"""


@dataclass
class BrowserSession:
    har_path: str | None = None
    storage_state: str | None = None
    headless: bool = True
    record_actions: bool = False
    start_url: str | None = None

    _pw: Any = field(default=None, repr=False)
    _browser: Any = field(default=None, repr=False)
    _context: Any = field(default=None, repr=False)
    page: Any = field(default=None, repr=False)
    actions: list[dict] = field(default_factory=list)

    def start(self) -> "BrowserSession":
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch(headless=self.headless)
        ctx_kwargs: dict[str, Any] = {}
        if self.har_path:
            ctx_kwargs["record_har_path"] = self.har_path
            ctx_kwargs["record_har_content"] = "embed"
        if self.storage_state:
            ctx_kwargs["storage_state"] = self.storage_state
        self._context = self._browser.new_context(**ctx_kwargs)
        if self.record_actions:
            self._context.expose_binding("__spyact", lambda source, data: self.actions.append(data))
            self._context.add_init_script(_ACTION_LOGGER)
        self.page = self._context.new_page()
        if self.start_url:
            self.page.goto(self.start_url)
        return self

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.stop()

    def cookie(self, name: str) -> str | None:
        for c in self._context.cookies():
            if c["name"] == name:
                return c["value"]
        return None

    def save_storage(self, path: str) -> None:
        self._context.storage_state(path=path)

    def save_actions(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.actions, fh)

    def stop(self) -> None:
        # Closing the context flushes the HAR to disk.
        try:
            if self._context:
                self._context.close()
        finally:
            if self._browser:
                self._browser.close()
            if self._pw:
                self._pw.stop()
