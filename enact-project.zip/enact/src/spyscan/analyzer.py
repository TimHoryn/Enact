"""Higher-level analysis of a session: which parameters are safe to edit, how
tokens flow from birth to use, and which blockers (CAPTCHA, 2FA, rate limits)
stand in the way.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .extractor import AuthContext, extract_auth
from .model import CapturedRequest, Session

# Parameter name -> semantic type.
_PAGINATION = {"page", "offset", "cursor", "limit", "per_page", "pagesize", "page_size", "skip"}
_SEARCH = {"q", "query", "search", "keyword", "term", "s"}
_SORT = {"sort", "order", "orderby", "order_by", "sort_by", "sortby", "dir"}
_FILTER = {
    "status", "category", "type", "filter", "state", "kind", "tag", "brand",
    "date_from", "date_to", "from", "to", "min", "max", "price_min", "price_max",
    "since", "until", "lang", "locale", "currency",
}
# Never offer these as editable — they are secrets / auth material.
_SECRET = {
    "password", "passwd", "pwd", "pass", "token", "access_token", "refresh_token",
    "csrf", "csrf_token", "csrftoken", "_csrf", "secret", "api_key", "apikey",
    "otp", "code", "pin", "signature", "sign",
}

_CSRF_HEADER_RE = re.compile(r"(x-)?(csrf|xsrf)", re.IGNORECASE)

# Reliable anti-bot signatures matched against the request URL (host + path).
_ANTIBOT_URL = [
    ("/cdn-cgi/challenge-platform", "Cloudflare Turnstile"),
    ("challenges.cloudflare.com", "Cloudflare Turnstile"),
    ("/turnstile/", "Cloudflare Turnstile"),
    ("hcaptcha.com", "hCaptcha"),
    ("talon_sdk", "hCaptcha (Epic Talon)"),
    ("/getcaptcha/", "hCaptcha"),
    ("recaptcha", "reCAPTCHA"),
    ("funcaptcha", "FunCaptcha / Arkose"),
    ("arkoselabs", "FunCaptcha / Arkose"),
    ("datadome", "DataDome"),
    ("px-captcha", "PerimeterX"),
    ("perimeterx", "PerimeterX"),
]

# Content types whose body is not worth scanning for captcha/2FA words
# (minified JS/CSS/fonts/images produce false positives).
_STATIC_CT = ("javascript", "css", "font", "woff", "image", "png", "jpg",
              "jpeg", "svg", "gif", "octet-stream", "video", "audio")

_CAPTCHA_BODY_SIGNS = [
    ("g-recaptcha", "reCAPTCHA"),
    ("cf-turnstile", "Cloudflare Turnstile"),
    ("h-captcha", "hCaptcha"),
]
_2FA_RE = re.compile(
    r"(two[- ]?factor|2fa|one[- ]time (code|password)|verification code|otp code|enter the code)",
    re.IGNORECASE,
)


@dataclass
class Param:
    name: str
    where: str   # "query" | "body"
    type: str    # pagination | search | sort | filter | identifier | parameter
    example: object = None


@dataclass
class EndpointInfo:
    method: str
    path: str
    url: str
    needs_auth: bool = False
    needs_csrf: bool = False
    editable_params: list[Param] = field(default_factory=list)
    entry_index: int = 0


@dataclass
class TokenFlow:
    token: str
    kind: str
    born_at: str
    used_in: list[str] = field(default_factory=list)


@dataclass
class Blocker:
    type: str      # captcha | 2fa | rate_limit
    service: str
    where: str     # first example location
    bypass: bool = False
    note: str = ""
    count: int = 1


@dataclass
class Analysis:
    endpoints: list[EndpointInfo] = field(default_factory=list)
    token_flow: list[TokenFlow] = field(default_factory=list)
    blockers: list[Blocker] = field(default_factory=list)


def _classify(name: str) -> str:
    n = name.lower()
    if n in _PAGINATION:
        return "pagination"
    if n in _SEARCH:
        return "search"
    if n in _SORT:
        return "sort"
    if n in _FILTER:
        return "filter"
    if n == "id" or n.endswith("_id") or n.endswith("id") and len(n) <= 6:
        return "identifier"
    return "parameter"


def _session_cookie_names(auth: AuthContext) -> set[str]:
    names = set()
    for name, c in auth.cookies.items():
        if re.search(r"(csrf|xsrf)", name, re.IGNORECASE):
            continue  # anti-CSRF tokens are not session auth
        if c.http_only or re.search(r"(session|sess|sid|auth|login)", name, re.IGNORECASE):
            names.add(name)
    return names


def _needs_auth(req: CapturedRequest, session_cookies: set[str]) -> bool:
    if req.headers.has("authorization"):
        return True
    return any(name in session_cookies for name in req.cookies)


def _needs_csrf(req: CapturedRequest) -> bool:
    return any(_CSRF_HEADER_RE.search(name) for name in req.headers.names())


def _editable_params(req: CapturedRequest) -> list[Param]:
    params: list[Param] = []
    for name, values in req.query.items():
        if name.lower() in _SECRET:
            continue
        params.append(Param(name, "query", _classify(name), values[0] if values else ""))
    if isinstance(req.post_json, dict):
        for name, value in req.post_json.items():
            if name.lower() in _SECRET:
                continue
            params.append(Param(name, "body", _classify(name), value))
    return params


def _detect_blockers(session: Session) -> list[Blocker]:
    """Deduped by (type, service): one finding per mechanism, with a count and a
    first example. URL signatures are reliable; body text is scanned only for
    document/JSON responses to avoid matching UI strings inside minified JS/CSS.
    """
    found: dict[tuple[str, str], Blocker] = {}

    def record(type_, service, where, note):
        key = (type_, service)
        b = found.get(key)
        if b is None:
            found[key] = Blocker(type=type_, service=service, where=where, bypass=False, note=note)
        else:
            b.count += 1

    for e in session.entries:
        where = f"{e.request.method} {e.request.path}"
        url = e.request.url.lower()
        ct = (e.response.content_type or "").lower()
        is_static = any(s in ct for s in _STATIC_CT)

        for sign, service in _ANTIBOT_URL:
            if sign in url:
                record("captcha", service, where, "CAPTCHA/anti-bot — never bypassed, a human decides.")
                break

        if e.response.status == 429:
            record("rate_limit", "HTTP 429", where, "Rate limit — slow down the replay.")

        if is_static or not e.response.body_text:
            continue
        body = e.response.body_text
        if "html" in ct or "json" in ct:
            for sign, service in _CAPTCHA_BODY_SIGNS:
                if sign in body.lower():
                    record("captcha", service, where, "CAPTCHA/anti-bot — never bypassed, a human decides.")
                    break
            if _2FA_RE.search(body):
                record("2fa", "2FA/OTP", where, "2FA — entered by a human.")
    return list(found.values())


def _token_flow(session: Session) -> list[TokenFlow]:
    auth = extract_auth(session)
    flows: list[TokenFlow] = []
    for tok in auth.tokens:
        born = next((w for w in tok.where_seen if w.startswith("resp body")), None)
        used = [w for w in tok.where_seen if not w.startswith("resp body")]
        flows.append(TokenFlow(
            token=tok.raw[:24] + ("…" if len(tok.raw) > 24 else ""),
            kind=tok.kind,
            born_at=born or (tok.where_seen[0] if tok.where_seen else "?"),
            used_in=used,
        ))
    return flows


def analyze(session: Session) -> Analysis:
    auth = extract_auth(session)
    session_cookies = _session_cookie_names(auth)
    endpoints: list[EndpointInfo] = []
    seen: set[tuple[str, str]] = set()
    for e in session.entries:
        key = (e.request.method, e.request.path)
        if key in seen:
            continue
        seen.add(key)
        endpoints.append(EndpointInfo(
            method=e.request.method,
            path=e.request.path,
            url=e.request.url,
            needs_auth=_needs_auth(e.request, session_cookies),
            needs_csrf=_needs_csrf(e.request),
            editable_params=_editable_params(e.request),
            entry_index=e.index,
        ))
    return Analysis(
        endpoints=endpoints,
        token_flow=_token_flow(session),
        blockers=_detect_blockers(session),
    )
