"""Three-tier replay engine, browser-first.

Tier 1 — raw HTTP (httpx): fast path for endpoints that tolerate it.
Tier 2 — in-browser fetch: issue the request from the live page so it carries
         live cookies, authentic TLS/HTTP-2 fingerprint and client hints.
Tier 3 — action replay: re-drive the recorded UI action so the page itself
         produces the (possibly JS-signed) request; capture it via interception.

Before every replay, traceable dynamic values (session cookies, CSRF, one-time
nonces) are refreshed from their origin so the request is never stale. Values
that are computed in-page (signatures) force Tier 3. Writes are dry-run unless
``allow_writes`` is set.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from urllib.parse import urlparse

from .browser import BrowserSession
from .model import ReplayRequest, Session
from .mutator import mutate
from .provenance import ProvenanceReport, analyze_provenance

_SKIP_HEADERS = {"cookie", "host", "content-length", "connection", "accept-encoding"}
_RETRYABLE = {429, 500, 502, 503, 504}


@dataclass
class ReplayResult:
    tier: str
    dry_run: bool
    status: int | None = None
    body: str | None = None
    request: ReplayRequest | None = None
    refreshed: dict | None = None
    note: str = ""


class ReplayEngine:
    def __init__(self, browser: BrowserSession, session: Session,
                 provenance: ProvenanceReport | None = None, allow_writes: bool = False,
                 retries: int = 2, backoff: float = 0.5):
        self.browser = browser
        self.session = session
        self.prov = provenance or analyze_provenance(session)
        self.allow_writes = allow_writes
        self.retries = retries
        self.backoff = backoff
        self._bearer_override: str | None = None
        self._refresh_ep, self._refresh_token = self._detect_refresh(session)

    @staticmethod
    def _detect_refresh(session: Session) -> tuple[str | None, str | None]:
        """Find a token-refresh endpoint and the refresh token to send it."""
        for e in session.entries:
            if e.request.method == "POST" and "refresh" in e.request.path.lower():
                tok = None
                if isinstance(e.request.post_json, dict):
                    tok = e.request.post_json.get("refresh_token") or e.request.post_json.get("refreshToken")
                return e.request.url, tok
        return None, None

    def _refresh_session(self) -> str | None:
        """Call the refresh endpoint through the live browser; return a fresh
        bearer token, or None if refresh is unavailable/failed."""
        if not self._refresh_ep:
            return None
        self._ensure_origin(self._refresh_ep)
        body = json.dumps({"refresh_token": self._refresh_token}) if self._refresh_token else "{}"
        js = """async (req) => {
            const r = await fetch(req.url, {method:'POST', headers:{'Content-Type':'application/json'},
                                            body:req.body, credentials:'include'});
            return {status: r.status, body: await r.text()};
        }"""
        try:
            res = self.browser.page.evaluate(js, {"url": self._refresh_ep, "body": body})
            if res["status"] == 200:
                data = json.loads(res["body"])
                tok = data.get("token") or data.get("access_token")
                if tok:
                    self._bearer_override = tok
                    return tok
        except Exception:
            pass
        return None

    # -- public ---------------------------------------------------------------

    def replay(self, index: int, edits: dict | None = None,
               allow_writes: bool | None = None, trigger_selector: str | None = None) -> ReplayResult:
        entry = self.session.entries[index]
        rr = mutate(ReplayRequest.from_request(entry.request), edits or {})
        allow = self.allow_writes if allow_writes is None else allow_writes
        needs_browser = self.prov.needs_browser(index)

        refreshed = self._collect_fresh(index)
        rr = self._apply_fresh(rr, refreshed)

        if rr.is_write and not allow:
            return ReplayResult(
                tier="prepared", dry_run=True, request=rr, refreshed=refreshed,
                note="dry-run: write request prepared, not sent. Pass allow_writes=True to send.",
            )

        # Tier 3 (action replay) only when a UI trigger is given — the only case
        # where regenerating an in-page computed value (e.g. a signature) is both
        # needed and possible. Otherwise replay through the live browser (tier 2):
        # it reuses the real session, and a stale computed header (like a random
        # x-request-id) is harmless for reads.
        if needs_browser and trigger_selector:
            return self._tier3_action(index, trigger_selector, edits, refreshed)
        return self._tier2_fetch(rr, refreshed)

    # -- fresh-value refresh --------------------------------------------------

    def _origin_url(self, entry_index: int) -> str:
        return self.session.entries[entry_index].request.url

    def _refetch_json(self, url: str):
        js = "async (u) => { const r = await fetch(u, {credentials:'include'}); return await r.text(); }"
        try:
            text = self.browser.page.evaluate(js, url)
            return json.loads(text)
        except Exception:
            return None

    def _json_path(self, node, dotted: str):
        cur = node
        for part in dotted.split("."):
            if isinstance(cur, list):
                cur = cur[int(part)]
            elif isinstance(cur, dict):
                cur = cur.get(part)
            else:
                return None
        return cur

    def _collect_fresh(self, index: int) -> dict:
        """Map each stale traced value -> its current fresh value."""
        fresh: dict[str, str] = {}
        for vo in self.prov.for_request(index):
            if vo.origin is None:  # computed — handled by Tier 3
                continue
            new = None
            loc = vo.location.lower()
            if loc.startswith("cookie "):
                name = vo.location.split(" ", 1)[1]
                new = self.browser.cookie(name)
            elif vo.origin.kind == "set_cookie":
                name = vo.origin.detail.replace("Set-Cookie", "").strip()
                new = self.browser.cookie(name)
            elif vo.origin.kind == "response_body" and vo.origin.detail.startswith("body."):
                data = self._refetch_json(self._origin_url(vo.origin.entry_index))
                if data is not None:
                    val = self._json_path(data, vo.origin.detail[len("body."):])
                    new = str(val) if val is not None else None
            elif vo.origin.kind == "html":
                try:
                    name = vo.origin.detail.split("name=")[1].rstrip("]")
                    new = self.browser.page.get_attribute(f'meta[name="{name}"]', "content")
                except Exception:
                    new = None
            if new:
                fresh[vo.value] = new
        return fresh

    def _apply_fresh(self, rr: ReplayRequest, fresh: dict) -> ReplayRequest:
        def sub(s: str | None) -> str | None:
            if not s:
                return s
            for old, new in fresh.items():
                s = s.replace(old, new)
            return s

        return ReplayRequest(
            method=rr.method,
            url=sub(rr.url),
            headers=[(k, sub(v)) for k, v in rr.headers],
            cookies={k: sub(v) for k, v in rr.cookies.items()},
            body=sub(rr.body),
        )

    # -- tiers ----------------------------------------------------------------

    def _ensure_origin(self, url: str):
        origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        cur = self.browser.page.url
        if not cur.startswith(origin):
            self.browser.page.goto(origin + "/")

    def _apply_bearer(self, headers: dict) -> dict:
        if not self._bearer_override:
            return headers
        out = {}
        for k, v in headers.items():
            out[k] = f"Bearer {self._bearer_override}" if k.lower() == "authorization" else v
        return out

    def _do_fetch(self, rr: ReplayRequest, headers: dict):
        js = """async (req) => {
            const opts = {method: req.method, headers: req.headers, credentials: 'include'};
            if (req.body && req.method !== 'GET' && req.method !== 'HEAD') opts.body = req.body;
            const r = await fetch(req.url, opts);
            return {status: r.status, body: await r.text()};
        }"""
        return self.browser.page.evaluate(js, {
            "url": rr.url, "method": rr.method, "headers": headers,
            "body": rr.body if rr.is_write else None,
        })

    def _tier2_fetch(self, rr: ReplayRequest, refreshed: dict) -> ReplayResult:
        self._ensure_origin(rr.url)
        base = {k: v for k, v in rr.headers if k.lower() not in _SKIP_HEADERS}
        note = ""
        refreshed_once = False
        res = {"status": None, "body": None}
        for attempt in range(self.retries + 1):
            try:
                res = self._do_fetch(rr, self._apply_bearer(base))
            except Exception as ex:                       # network / navigation error
                if attempt < self.retries:
                    time.sleep(self.backoff * (2 ** attempt))
                    continue
                return ReplayResult(tier="in_browser_fetch", dry_run=False, status=None,
                                    body=None, request=rr, refreshed=refreshed, note=f"network error: {ex}")
            status = res["status"]
            if status in _RETRYABLE and attempt < self.retries:
                note = f"retry after {status}"
                time.sleep(self.backoff * (2 ** attempt))
                continue
            if status in (401, 403) and not refreshed_once and self._refresh_ep:
                if self._refresh_session():
                    refreshed_once = True
                    note = "session refreshed"
                    continue
            break
        return ReplayResult(tier="in_browser_fetch", dry_run=False, status=res["status"],
                            body=res["body"], request=rr, refreshed=refreshed, note=note)

    def _tier3_action(self, index: int, trigger_selector: str | None,
                      edits: dict | None, refreshed: dict) -> ReplayResult:
        from .interceptor import install_capture

        entry = self.session.entries[index]
        path = entry.request.path
        start = self.browser.start_url or (entry.request.origin + "/login")
        self.browser.page.goto(start)

        body_override = None
        if edits and "body" in edits and entry.request.post_json:
            merged = dict(entry.request.post_json)
            merged.update({k: v for k, v in edits["body"].items() if v is not None})
            body_override = json.dumps(merged)

        cap = install_capture(self.browser.page, path, body_override=body_override)
        if trigger_selector:
            try:
                with self.browser.page.expect_response(lambda r: path in r.url, timeout=5000):
                    self.browser.page.click(trigger_selector)
            except Exception:
                pass
        resp = cap.last_response()
        if not resp:
            return ReplayResult(tier="action_replay", dry_run=False, status=None,
                                note="action produced no request; pass trigger_selector", refreshed=refreshed)
        return ReplayResult(tier="action_replay", dry_run=False, status=resp["status"],
                            body=resp["body"], refreshed=refreshed)
