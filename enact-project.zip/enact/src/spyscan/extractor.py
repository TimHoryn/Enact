"""Extract the authorization context from a captured session.

This answers: which cookies carry auth (and how safe are they), which request
headers are auth-bearing, and what tokens (JWT / opaque) are in play — decoded
where possible, with lifetime and refresh hints.
"""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass, field
from typing import Any

from .model import Cookie, Session

# Request headers that carry authorization/anti-CSRF material. Matched
# case-insensitively, by exact name or by a telltale prefix.
_AUTH_HEADER_NAMES = {
    "authorization",
    "cookie",
    "x-csrf-token",
    "x-xsrf-token",
    "csrf-token",
    "x-api-key",
    "api-key",
    "x-auth-token",
    "x-access-token",
    "x-session-token",
    "x-requested-with",
}
_AUTH_HEADER_PREFIXES = ("x-csrf", "x-xsrf", "x-auth", "x-access", "x-session", "x-api")

_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*")


@dataclass
class TokenInfo:
    raw: str
    kind: str  # "jwt" | "opaque"
    claims: dict[str, Any] = field(default_factory=dict)
    exp: int | None = None
    where_seen: list[str] = field(default_factory=list)


@dataclass
class AuthContext:
    cookies: dict[str, Cookie] = field(default_factory=dict)
    auth_headers: dict[str, str] = field(default_factory=dict)
    tokens: list[TokenInfo] = field(default_factory=list)
    refresh_token: str | None = None
    token_lifetime: int | None = None


def _is_auth_header(name: str) -> bool:
    n = name.lower()
    if n in _AUTH_HEADER_NAMES:
        return True
    return any(n.startswith(p) for p in _AUTH_HEADER_PREFIXES)


def _b64url_decode(seg: str) -> bytes:
    pad = "=" * (-len(seg) % 4)
    return base64.urlsafe_b64decode(seg + pad)


def decode_jwt(token: str) -> dict[str, Any] | None:
    """Decode a JWT payload without verifying the signature (we only inspect)."""
    parts = token.split(".")
    if len(parts) != 3:
        return None
    try:
        payload = json.loads(_b64url_decode(parts[1]))
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def _scan_tokens(text: str, where: str, found: dict[str, TokenInfo]) -> None:
    for m in _JWT_RE.finditer(text or ""):
        raw = m.group(0)
        claims = decode_jwt(raw)
        if raw not in found:
            found[raw] = TokenInfo(
                raw=raw,
                kind="jwt" if claims is not None else "opaque",
                claims=claims or {},
                exp=(claims or {}).get("exp"),
            )
        if where not in found[raw].where_seen:
            found[raw].where_seen.append(where)


def extract_auth(session: Session) -> AuthContext:
    ctx = AuthContext()
    tokens: dict[str, TokenInfo] = {}

    for e in session.entries:
        loc = f"{e.request.method} {e.request.path}"

        # Cookies: Set-Cookie carries the authoritative security flags.
        for c in e.response.set_cookies:
            ctx.cookies[c.name] = c
        # Cookies seen only on requests (never re-set) still matter.
        for name, value in e.request.cookies.items():
            if name not in ctx.cookies:
                ctx.cookies[name] = Cookie(name=name, value=value)

        # Auth-bearing request headers (last value wins — freshest).
        for name, value in e.request.headers.items():
            if _is_auth_header(name) and name.lower() != "cookie":
                ctx.auth_headers[name] = value

        # Tokens anywhere we can see them.
        for name, value in e.request.headers.items():
            _scan_tokens(value, f"req header {name} @ {loc}", tokens)
        if e.request.post_data:
            _scan_tokens(e.request.post_data, f"req body @ {loc}", tokens)
        if e.response.body_text:
            _scan_tokens(e.response.body_text, f"resp body @ {loc}", tokens)

        # Refresh token + lifetime from login-style JSON responses.
        body = e.response.body_json
        if isinstance(body, dict):
            if ctx.refresh_token is None and isinstance(body.get("refresh_token"), str):
                ctx.refresh_token = body["refresh_token"]
            for key in ("expires_in", "token_lifetime", "expires"):
                if ctx.token_lifetime is None and isinstance(body.get(key), int):
                    ctx.token_lifetime = body[key]

    ctx.tokens = list(tokens.values())
    return ctx
