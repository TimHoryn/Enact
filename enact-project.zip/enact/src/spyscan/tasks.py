"""Task layer on top of the replay engine — outcome-first operations an agent
or person runs: collect (export a whole resource to a table), and helpers for
monitoring / bulk writes. Built entirely on ReplayEngine.
"""

from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import dataclass

from .replay import ReplayEngine


@dataclass
class CollectResult:
    rows: int
    pages: int
    keys: list[str]
    out: str | None
    sample: list[dict]


def _extract_rows(data, page: int):
    """Return (rows, has_more). rows is None when the response is not a list."""
    if isinstance(data, list):
        return data, bool(data)
    if isinstance(data, dict):
        arr_key = "results" if isinstance(data.get("results"), list) else None
        if arr_key is None:
            for k, v in data.items():
                if isinstance(v, list):
                    arr_key = k
                    break
        if arr_key is None:
            return None, False
        chunk = data.get(arr_key) or []
        if "next" in data:
            more = bool(data.get("next"))
        elif "page" in data and "pages" in data:
            more = (data.get("page") or page) < (data.get("pages") or 1)
        elif "count" in data:
            more = len(chunk) > 0  # unknown total -> keep going until empty
        else:
            more = False
        return chunk, more
    return None, False


def _flat(v):
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    return v


def collect(engine: ReplayEngine, endpoint: str, out_path: str | None = None,
            max_pages: int = 50, page_param: str = "page") -> CollectResult:
    """Replay a list endpoint across all pages and flatten the rows. Handles
    DRF-style ``{count, next, results}`` and bare lists."""
    method, _, path = endpoint.partition(" ")
    idx = next((e.index for e in engine.session.entries
                if e.request.method == method and e.request.path == path), None)
    if idx is None:
        raise ValueError(f"endpoint not found in capture: {endpoint}")

    rows: list = []
    pages = 0
    page = 1
    while page <= max_pages:
        res = engine.replay(idx, edits={"query": {page_param: page}})
        if res.status != 200 or not res.body:
            break
        try:
            data = json.loads(res.body)
        except Exception:
            break

        chunk, more = _extract_rows(data, page)
        if chunk is None:          # not a list response — single object
            rows.append(data)
            pages += 1
            break
        rows.extend(chunk)
        pages += 1
        if not chunk or not more:
            break
        page += 1

    keys: list[str] = []
    for r in rows:
        if isinstance(r, dict):
            for k in r:
                if k not in keys:
                    keys.append(k)
    if out_path and rows:
        with open(out_path, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                if isinstance(r, dict):
                    w.writerow({k: _flat(r.get(k)) for k in keys})
    sample = [r for r in rows[:3] if isinstance(r, dict)]
    return CollectResult(rows=len(rows), pages=pages, keys=keys, out=out_path, sample=sample)


# --- Actions / forms (tier-3 style, reuse recorded UI steps) -----------------

def run_actions(browser, actions, overrides=None, capture_path=None, start_url=None):
    """Replay recorded UI steps (fill / click / submit) in the live browser,
    substituting field values from ``overrides`` (keyed by selector). Optionally
    capture the response whose URL contains ``capture_path``. This is how writes
    and form submissions are reproduced — the page itself issues the request."""
    from .interceptor import install_capture

    page = browser.page
    if start_url:
        page.goto(start_url)
    overrides = overrides or {}
    cap = install_capture(page, capture_path) if capture_path else None
    done = []
    for a in actions:
        sel, typ = a.get("selector"), a.get("type")
        if not sel or sel == "document":
            continue
        try:
            if typ == "fill":
                val = overrides.get(sel, a.get("value", ""))
                page.fill(sel, str(val))
                done.append(f"fill {sel} = {val}")
            elif typ in ("click", "submit"):
                page.click(sel)
                done.append(f"{typ} {sel}")
            page.wait_for_timeout(200)
        except Exception as ex:
            done.append(f"skip {sel} ({type(ex).__name__})")
    resp = cap.last_response() if cap else None
    return {"steps": done, "response": resp}


# --- Bulk writes -------------------------------------------------------------

def bulk(engine: ReplayEngine, endpoint: str, items, allow_writes=False):
    """Run a write endpoint once per item. Each item is an ``edits`` dict (e.g.
    {"body": {"product_id": 7}}). Dry-run unless ``allow_writes``."""
    method, _, path = endpoint.partition(" ")
    idx = next((e.index for e in engine.session.entries
                if e.request.method == method and e.request.path == path), None)
    if idx is None:
        raise ValueError(f"endpoint not found: {endpoint}")
    results = []
    for it in items:
        res = engine.replay(idx, edits=it, allow_writes=allow_writes)
        results.append({"edits": it, "status": res.status, "dry_run": res.dry_run})
    return results


# --- Monitoring --------------------------------------------------------------

def _digest(body: str | None) -> str:
    try:
        norm = json.dumps(json.loads(body or ""), sort_keys=True, ensure_ascii=False)
    except Exception:
        norm = body or ""
    return hashlib.sha256(norm.encode()).hexdigest()


def snapshot(engine: ReplayEngine, endpoint: str) -> str:
    method, _, path = endpoint.partition(" ")
    idx = next((e.index for e in engine.session.entries
                if e.request.method == method and e.request.path == path), None)
    if idx is None:
        raise ValueError(f"endpoint not found: {endpoint}")
    res = engine.replay(idx)
    return _digest(res.body)


def monitor(engine: ReplayEngine, endpoint: str, baseline: str | None):
    """Compare current snapshot to a baseline digest. Returns (changed, digest)."""
    cur = snapshot(engine, endpoint)
    return (baseline is not None and cur != baseline), cur
