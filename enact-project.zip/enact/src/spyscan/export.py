"""Assemble the single session.json snapshot (the README format) and an OpenAPI
spec from a captured session. Pulls together extractor, analyzer, provenance and
privacy. Also builds the node/link graph the 3D viz renders.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
from urllib.parse import urlparse

from .analyzer import analyze
from .extractor import extract_auth
from .model import Session
from .privacy import audit_privacy, _first_party_domains
from .provenance import analyze_provenance
from .trackers import match_tracker, registrable_domain


def _primary_site(session: Session) -> str:
    hosts = Counter(e.request.host for e in session.entries if e.request.host)
    # Prefer the most common host that is not an obvious third party.
    return hosts.most_common(1)[0][0] if hosts else ""


def _shape(node) -> str:
    """Short human/agent-readable summary of a response body shape."""
    if isinstance(node, dict):
        keys = list(node.keys())
        return "{" + ", ".join(keys[:8]) + ("…" if len(keys) > 8 else "") + "}"
    if isinstance(node, list):
        if node and isinstance(node[0], dict):
            inner = list(node[0].keys())
            return f"[{len(node)}× {{" + ", ".join(inner[:6]) + "}}]"
        return f"[{len(node)} items]"
    if node is None:
        return ""
    return type(node).__name__


_STATIC_EXT = (".js", ".mjs", ".cjs", ".css", ".woff", ".woff2", ".ttf", ".otf",
               ".png", ".jpg", ".jpeg", ".svg", ".gif", ".ico", ".map", ".webp",
               ".mp4", ".avif", ".wasm")


def _is_asset(path: str) -> bool:
    return path.lower().rsplit("?", 1)[0].endswith(_STATIC_EXT)


def _useful_endpoint(ep) -> bool:
    """A real, callable API endpoint — not a static asset, anti-bot challenge or
    tracker beacon (those live in the blockers/trackers sections)."""
    host = urlparse(ep.url).netloc
    if not host:
        return False
    if _is_asset(ep.path):
        return False
    if "/cdn-cgi/challenge-platform" in ep.path or "challenges.cloudflare.com" in host:
        return False
    if match_tracker(host):
        return False
    return True


def build_api_map(session: Session) -> dict:
    """Request map grouped by host: the useful API surface (static assets,
    anti-bot challenges and trackers are left out), sorted."""
    analysis = analyze(session)
    hosts: dict[str, list[dict]] = {}
    for ep in analysis.endpoints:
        if not _useful_endpoint(ep):
            continue
        host = urlparse(ep.url).netloc
        entry = session.entries[ep.entry_index]
        hosts.setdefault(host, []).append({
            "method": ep.method,
            "path": ep.path,
            "needs_auth": ep.needs_auth,
            "needs_csrf": ep.needs_csrf,
            "returns": _shape(entry.response.body_json),
            "params": [{"name": p.name, "type": p.type, "where": p.where, "example": p.example}
                       for p in ep.editable_params],
        })
    for h in hosts:
        hosts[h].sort(key=lambda x: (x["path"], x["method"]))
    return dict(sorted(hosts.items(), key=lambda kv: -len(kv[1])))


def _looks_id(seg: str) -> bool:
    if seg.isdigit():
        return True
    if len(seg) >= 16 and sum(c.isdigit() for c in seg) >= 4 and ("-" in seg or seg.isalnum()):
        return True
    return False


def _resource_name(path: str) -> str:
    segs = [s for s in path.split("/") if s and not _looks_id(s)]
    return segs[-1] if segs else path.strip("/") or "root"


def suggest_tasks(api_map: dict) -> list[dict]:
    """Turn the endpoint map into concrete, outcome-first tasks an agent or
    person would actually run (export / monitor / bulk-write / reverse)."""
    tasks: list[dict] = []
    seen: set[str] = set()
    for host, eps in api_map.items():
        for e in eps:
            path, method, ret = e["path"], e["method"], e.get("returns", "")
            key = f"{method} {path}"
            if key in seen:
                continue
            seen.add(key)
            res = _resource_name(path)
            is_list = ("results" in ret) or ("×" in ret) or any(p["type"] == "pagination" for p in e.get("params", []))
            if method == "GET" and is_list:
                tasks.append({"kind": "collect", "title": f"Collect all \u00ab{res}\u00bb into a table",
                              "endpoint": key, "command": f'spyscan collect capture "{key}" --out {res}.csv',
                              "note": "paginates all pages → CSV/Excel"})
            elif method in ("POST", "PUT", "PATCH", "DELETE"):
                tasks.append({"kind": "write", "title": f"Change: {method.lower()} \u00ab{res}\u00bb (bulk)",
                              "endpoint": key, "command": f'spyscan replay capture --endpoint "{key}" --allow-writes',
                              "note": "write/action; dry-run by default, confirm first"})
            elif method == "GET" and ret.startswith("{"):
                tasks.append({"kind": "read", "title": f"Fetch \u00ab{res}\u00bb",
                              "endpoint": key, "command": f'spyscan replay capture --endpoint "{key}"',
                              "note": "single object"})
    order = {"collect": 0, "write": 1, "read": 2}
    tasks.sort(key=lambda t: order.get(t["kind"], 9))
    return tasks


def build_params_catalog(session: Session) -> dict:
    """All editable parameters grouped by kind (pagination/filter/search/…)."""
    analysis = analyze(session)
    cat: dict[str, dict[str, dict]] = {}
    for ep in analysis.endpoints:
        if not _useful_endpoint(ep):
            continue
        loc = f"{ep.method} {ep.path}"
        for p in ep.editable_params:
            bucket = cat.setdefault(p.type, {})
            item = bucket.setdefault(p.name, {"name": p.name, "example": p.example, "where": "", "endpoints": []})
            item["where"] = p.where
            if loc not in item["endpoints"]:
                item["endpoints"].append(loc)
    return {t: sorted(v.values(), key=lambda x: -len(x["endpoints"])) for t, v in cat.items()}


def build_session_json(session: Session) -> dict:
    auth = extract_auth(session)
    analysis = analyze(session)
    prov = analyze_provenance(session)
    privacy = audit_privacy(session)
    site = _primary_site(session)

    cookies = {
        name: {
            "value": c.value,
            "domain": c.domain,
            "secure": c.secure,
            "httpOnly": c.http_only,
            "sameSite": c.same_site,
        }
        for name, c in auth.cookies.items()
    }

    replay_recipe = []
    for i, ep in enumerate(analysis.endpoints, start=1):
        origins = prov.for_request(ep.entry_index)
        entry = session.entries[ep.entry_index]
        replay_recipe.append({
            "step": i,
            "endpoint": f"{ep.method} {ep.path}",
            "host": urlparse(ep.url).netloc,
            "needs_auth": ep.needs_auth,
            "needs_csrf": ep.needs_csrf,
            "needs_browser": prov.needs_browser(ep.entry_index),
            "returns": _shape(entry.response.body_json),
            "status": entry.response.status,
            "editable_params": [asdict(p) for p in ep.editable_params],
            "refresh_plan": prov.refresh_plan(ep.entry_index),
            "value_origins": [
                {
                    "location": vo.location,
                    "origin": (asdict(vo.origin) if vo.origin else None),
                    "computed": vo.computed,
                }
                for vo in origins
            ],
        })

    doc = {
        "_meta": {
            "tool": "spyscan",
            "recorded_at": datetime.now(timezone.utc).isoformat(),
            "site": site,
            "entry_count": len(session.entries),
        },
        "auth": {
            "cookies": cookies,
            "headers": auth.auth_headers,
            "refresh_token": auth.refresh_token,
            "token_lifetime": auth.token_lifetime,
            "tokens": [
                {"kind": t.kind, "claims": t.claims, "exp": t.exp, "preview": t.raw[:24] + "…"}
                for t in auth.tokens
            ],
        },
        "endpoints": [
            {"method": e.method, "path": e.path, "host": urlparse(e.url).netloc,
             "needs_auth": e.needs_auth, "needs_csrf": e.needs_csrf}
            for e in analysis.endpoints
        ],
        "replay_recipe": replay_recipe,
        "blockers_detected": [asdict(b) for b in analysis.blockers],
        "token_flow": [asdict(t) for t in analysis.token_flow],
        "privacy": {
            "trackers": [asdict(t) for t in privacy.trackers],
            "leaks": [asdict(l) for l in privacy.leaks],
            "cookies": [asdict(c) for c in privacy.cookies],
        },
        "api_map": build_api_map(session),
        "params_catalog": build_params_catalog(session),
        "graph": build_graph(session),
    }
    doc["tasks"] = suggest_tasks(doc["api_map"])
    return doc


SITE_ID = "__site__"


def build_graph(session: Session) -> dict:
    """Host-level data-flow graph: a central site node, one node per host
    (first_party / third_party / tracker) sized by request count, plus blocker
    nodes. Links: flow (site→host), tracker, leak, blocker. Rendered by the
    built-in canvas viz — no external library needed."""
    analysis = analyze(session)
    privacy = audit_privacy(session)
    site = _primary_site(session)
    first = _first_party_domains(session)
    tracker_hosts = {t.host: t for t in privacy.trackers}

    host_count: Counter = Counter()
    host_auth: dict[str, bool] = {}
    for e in session.entries:
        if e.request.host:
            host_count[e.request.host] += 1
    for ep in analysis.endpoints:
        h = urlparse(ep.url).netloc
        if ep.needs_auth:
            host_auth[h] = True

    max_count = max(host_count.values()) if host_count else 1
    nodes: list[dict] = [{"id": SITE_ID, "type": "site", "label": site, "count": max_count}]
    links: list[dict] = []

    for host, count in host_count.most_common():
        if match_tracker(host):
            group = "tracker"
        elif registrable_domain(host) in first:
            group = "first_party"
        else:
            group = "third_party"
        node = {"id": host, "type": group, "label": host, "count": count,
                "auth": host_auth.get(host, False)}
        if host in tracker_hosts:
            node["service"] = tracker_hosts[host].service
            node["category"] = tracker_hosts[host].category
        nodes.append(node)
        links.append({"source": SITE_ID, "target": host,
                      "type": "tracker" if group == "tracker" else "flow", "weight": count})

    for leak in privacy.leaks:
        if leak.third_party and leak.to_host in host_count:
            links.append({"source": SITE_ID, "target": leak.to_host, "type": "leak",
                          "kind": leak.kind, "severity": leak.severity})

    for b in analysis.blockers:
        bid = f"blocker:{b.service}"
        if not any(n["id"] == bid for n in nodes):
            nodes.append({"id": bid, "type": "blocker", "label": b.service, "count": b.count})
        links.append({"source": SITE_ID, "target": bid, "type": "blocker"})

    return {"nodes": nodes, "links": links}


def build_openapi(session: Session) -> dict:
    analysis = analyze(session)
    site = _primary_site(session)
    paths: dict[str, dict] = {}
    for ep in analysis.endpoints:
        method = ep.method.lower()
        params = []
        for p in ep.editable_params:
            if p.where == "query":
                params.append({
                    "name": p.name, "in": "query", "required": False,
                    "schema": {"type": "string"}, "example": p.example,
                    "x-spyscan-type": p.type,
                })
        op = {
            "summary": f"{ep.method} {ep.path}",
            "security": [{"cookieAuth": []}] if ep.needs_auth else [],
            "parameters": params,
            "responses": {"200": {"description": "captured"}},
        }
        paths.setdefault(ep.path, {})[method] = op
    return {
        "openapi": "3.0.3",
        "info": {"title": f"API of {site}", "version": "captured-by-spyscan"},
        "servers": [{"url": f"https://{site}"}],
        "paths": paths,
        "components": {"securitySchemes": {"cookieAuth": {"type": "apiKey", "in": "cookie", "name": "session"}}},
    }
