"""Value provenance: for every dynamic value a request carries, find where it
came from, and build the refresh plan needed to replay that request with fresh
values.

This is what lets spyscan replay requests that depend on one-time tokens and
rotating cookies: instead of reusing a frozen snapshot, it traces each value to
its origin request and re-runs that origin first. Values it cannot trace
upstream are classed as *computed* (produced by in-page JS) and flagged as
needing the live browser to regenerate.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .model import Entry, Session

# Request headers that are not worth tracing (static/transport, never auth).
_BORING_HEADERS = {
    "host", "user-agent", "accept", "accept-encoding", "accept-language",
    "content-type", "content-length", "connection", "origin", "referer",
    "cache-control", "pragma", "dnt", "upgrade-insecure-requests",
    "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest", "sec-fetch-user",
}

_MIN_TRACE_LEN = 8  # shorter values are too ambiguous to trace reliably
_MAX_SCAN_BODY = 500_000  # skip body-based origin search for very large responses

# A value worth tracing looks like an opaque token/id: no spaces, quotes,
# commas or semicolons (which mark structured/transport headers like
# sec-ch-ua, accept, priority). This keeps browser-added noise out.
_OPAQUE_RE = re.compile(r"^[A-Za-z0-9._~\-=/+]{8,}$")

# Header names that are always auth-bearing even if the value is short.
_AUTH_NAMES = ("authorization", "x-csrf", "x-xsrf", "csrf", "x-nonce",
               "x-request-nonce", "x-api-key", "x-auth", "x-access",
               "x-session", "x-signature")


@dataclass
class Origin:
    kind: str          # set_cookie | response_body | html | response_text
    entry_index: int   # the upstream request that produced the value
    detail: str        # e.g. "Set-Cookie session_id" or "body.token"


@dataclass
class ValueOrigin:
    location: str      # e.g. "header X-CSRF-Token", "cookie session_id"
    value: str
    origin: Origin | None = None
    computed: bool = False  # True when no upstream source found (in-page JS)


@dataclass
class ProvenanceReport:
    session: Session
    _per_request: dict[int, list[ValueOrigin]] = field(default_factory=dict)

    def for_request(self, index: int) -> list[ValueOrigin]:
        return self._per_request.get(index, [])

    def needs_browser(self, index: int) -> bool:
        return any(vo.computed for vo in self.for_request(index))

    def refresh_plan(self, index: int) -> list[int]:
        """Upstream entry indices to replay (in chronological order) so that the
        traceable values of ``index`` are fresh before it is re-issued."""
        idxs = {
            vo.origin.entry_index
            for vo in self.for_request(index)
            if vo.origin is not None
        }
        return sorted(i for i in idxs if i < index)


def _is_auth_name(name: str) -> bool:
    n = name.lower()
    return any(n == a or n.startswith(a) for a in _AUTH_NAMES)


def _iter_traced_values(req) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for name, value in req.cookies.items():
        if value and _OPAQUE_RE.match(value):
            out.append((f"cookie {name}", value))
    for name, value in req.headers.items():
        n = name.lower()
        if n == "cookie" or n in _BORING_HEADERS or not value:
            continue
        if value.lower().startswith("bearer ") and len(value) > 7:
            out.append((f"header {name} (bearer)", value[7:].strip()))
        elif _is_auth_name(n) or _OPAQUE_RE.match(value):
            out.append((f"header {name}", value))
    return out


def _find_in_json(node: Any, target: str, path: str = "") -> str | None:
    if isinstance(node, dict):
        for k, v in node.items():
            hit = _find_in_json(v, target, f"{path}.{k}" if path else k)
            if hit:
                return hit
    elif isinstance(node, list):
        for i, v in enumerate(node):
            hit = _find_in_json(v, target, f"{path}.{i}" if path else str(i))
            if hit:
                return hit
    else:
        if node is not None and str(node) == target:
            return path or "(root)"
    return None


def _meta_name_for(html: str, value: str) -> str | None:
    for m in re.finditer(r"<meta\b[^>]*>", html, re.IGNORECASE):
        tag = m.group(0)
        if value in tag:
            nm = re.search(r'name\s*=\s*["\']([^"\']+)["\']', tag, re.IGNORECASE)
            return nm.group(1) if nm else "?"
    return None


def _find_origin(value: str, upstream: list[Entry]) -> Origin | None:
    # Nearest upstream first — the freshest producer wins.
    for e in sorted(upstream, key=lambda x: x.index, reverse=True):
        resp = e.response
        # 1) Set-Cookie carries the value verbatim.
        for c in resp.set_cookies:
            if c.value == value:
                return Origin("set_cookie", e.index, f"Set-Cookie {c.name}")
        body = resp.body_text or ""
        if len(body) > _MAX_SCAN_BODY:
            continue  # too large to scan cheaply; set-cookie above still applies
        # 2) A field in a JSON response body.
        if resp.body_json is not None:
            path = _find_in_json(resp.body_json, value)
            if path:
                return Origin("response_body", e.index, f"body.{path}")
        # 3) An HTML page — meta tag / inline.
        ctype = (resp.content_type or "").lower()
        if "html" in ctype and value in body:
            meta = _meta_name_for(body, value)
            detail = f"meta[name={meta}]" if meta else "inline html"
            return Origin("html", e.index, detail)
        # 4) Anywhere else in a text body.
        if value in body:
            return Origin("response_text", e.index, "response text")
    return None


def analyze_provenance(session: Session) -> ProvenanceReport:
    report = ProvenanceReport(session=session)
    for e in session.entries:
        upstream = session.before(e.index)
        origins: list[ValueOrigin] = []
        for location, value in _iter_traced_values(e.request):
            origin = _find_origin(value, upstream)
            origins.append(
                ValueOrigin(
                    location=location,
                    value=value,
                    origin=origin,
                    computed=origin is None,
                )
            )
        report._per_request[e.index] = origins
    return report
