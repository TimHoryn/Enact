"""Agent-facing exports: a structured capability manifest (`agent.json`) and
function-calling tool schemas (`tools.json`) built from an assembled session doc.
These let an LLM agent discover and call the captured API as typed tools.
"""

from __future__ import annotations

import re

_JSON_TYPE = {
    "pagination": "integer",
    "identifier": "string",
    "filter": "string",
    "search": "string",
    "sort": "string",
    "parameter": "string",
}


def _op_id(method: str, path: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", f"{method} {path}".lower()).strip("_")
    return slug[:60]


def _resource(path: str) -> str:
    segs = [s for s in path.split("/") if s and not re.fullmatch(r"[0-9a-f-]{8,}|\d+", s)]
    return segs[-1] if segs else "root"


def build_manifest(doc: dict) -> dict:
    m = doc.get("_meta", {})
    auth = doc.get("auth", {})
    ops = []
    tasks_by_ep = {t["endpoint"]: t for t in doc.get("tasks", [])}
    for host, eps in doc.get("api_map", {}).items():
        for e in eps:
            ep = f"{e['method']} {e['path']}"
            params = [{
                "name": p["name"], "kind": p["type"],
                "in": p.get("where", "query"), "example": p.get("example"),
            } for p in e.get("params", [])]
            ops.append({
                "id": _op_id(e["method"], e["path"]),
                "method": e["method"], "path": e["path"], "host": host,
                "needs_auth": e.get("needs_auth", False),
                "is_write": e["method"] in ("POST", "PUT", "PATCH", "DELETE"),
                "returns": e.get("returns", ""),
                "params": params,
                "task": (tasks_by_ep.get(ep) or {}).get("title"),
                "example_call": f"sp.call({ep!r}" + (
                    ", " + ", ".join(f"{p['name']}={p['example']!r}" for p in params[:2]) if params else "") + ")",
            })
    return {
        "tool": "spyscan",
        "site": m.get("site"),
        "recorded_at": m.get("recorded_at"),
        "auth": {
            "has_session": bool(auth.get("cookies")),
            "token_kinds": sorted({t.get("kind") for t in auth.get("tokens", [])}),
            "can_refresh": bool(auth.get("refresh_token")),
        },
        "rules": [
            "GET — go ahead; POST/PUT/PATCH/DELETE — only with allow_writes=True (dry-run by default).",
            "CAPTCHA/2FA/anti-bot are never bypassed — on a blocker, stop and report.",
            "The engine refreshes cookies/one-time tokens and re-auths on 401 by itself.",
        ],
        "how_to_use": "Python: `from spyscan.agent import Spyscan; sp=Spyscan.open('<dir>'); "
                      "sp.call('GET /path', page=2)`. Or hand an LLM the schemas from tools.json.",
        "operations": ops,
        "blockers": [{"type": b["type"], "service": b["service"]} for b in doc.get("blockers_detected", [])],
    }


def build_tool_schemas(doc: dict) -> list[dict]:
    """One function-calling tool per useful operation (Anthropic/OpenAI style)."""
    tools = []
    seen: set[str] = set()
    for host, eps in doc.get("api_map", {}).items():
        for e in eps:
            name = _op_id(e["method"], e["path"])
            if name in seen:
                continue
            seen.add(name)
            props = {}
            for p in e.get("params", []):
                props[p["name"]] = {
                    "type": _JSON_TYPE.get(p["type"], "string"),
                    "description": f"{p['type']}" + (f", e.g. {p['example']}" if p.get("example") not in (None, "") else ""),
                }
            desc = f"{e['method']} {e['path']}"
            if e.get("returns"):
                desc += f" → {e['returns']}"
            if e.get("needs_auth"):
                desc += " (needs auth)"
            if e["method"] in ("POST", "PUT", "PATCH", "DELETE"):
                desc += " [WRITE — requires allow_writes]"
            tools.append({
                "name": name,
                "description": desc,
                "input_schema": {"type": "object", "properties": props, "required": []},
            })
    return tools
