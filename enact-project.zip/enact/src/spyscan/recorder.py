"""Record a browser session to HAR + storage state + action log.

As a library: use ``BrowserSession`` directly and drive the page.
As a CLI: ``python -m spyscan.recorder https://site --out ./capture`` opens a
headed browser; you log in and browse; press Enter in the terminal to stop.
"""

from __future__ import annotations

import os
import sys

from .browser import BrowserSession


def new_recording(url: str, out_dir: str, headless: bool = True) -> BrowserSession:
    os.makedirs(out_dir, exist_ok=True)
    har = os.path.join(out_dir, "session.har")
    return BrowserSession(har_path=har, record_actions=True, headless=headless, start_url=url)


def finish(session: BrowserSession, out_dir: str) -> dict:
    session.save_storage(os.path.join(out_dir, "storage_state.json"))
    session.save_actions(os.path.join(out_dir, "actions.json"))
    session.stop()  # flushes HAR
    return {
        "har": os.path.join(out_dir, "session.har"),
        "storage_state": os.path.join(out_dir, "storage_state.json"),
        "actions": os.path.join(out_dir, "actions.json"),
    }


def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]
    if not argv:
        print("usage: python -m spyscan.recorder <url> [--out DIR]")
        return 2
    url = argv[0]
    out_dir = "./capture"
    if "--out" in argv:
        out_dir = argv[argv.index("--out") + 1]
    sess = new_recording(url, out_dir, headless=False).start()
    print(f"Recording {url}. Log in / browse, then press Enter here to stop…")
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        pass
    paths = finish(sess, out_dir)
    print("Saved:", paths)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
