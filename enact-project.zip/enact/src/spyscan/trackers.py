"""Known tracker domains -> (service, category).

Categories: analytics | ads | session_replay | cdp | tagmanager | social.
Matching is by registrable-domain suffix, so subdomains are covered.
This is a static, self-contained list — no remote lookups.
"""

TRACKERS: dict[str, tuple[str, str]] = {
    # --- Analytics ---
    "google-analytics.com": ("Google Analytics", "analytics"),
    "analytics.google.com": ("Google Analytics 4", "analytics"),
    "mixpanel.com": ("Mixpanel", "analytics"),
    "amplitude.com": ("Amplitude", "analytics"),
    "heap.io": ("Heap", "analytics"),
    "heapanalytics.com": ("Heap", "analytics"),
    "segment.io": ("Segment", "cdp"),
    "segment.com": ("Segment", "cdp"),
    "matomo.cloud": ("Matomo", "analytics"),
    "plausible.io": ("Plausible", "analytics"),
    "statcounter.com": ("StatCounter", "analytics"),
    "quantserve.com": ("Quantcast", "analytics"),
    "chartbeat.com": ("Chartbeat", "analytics"),
    "kissmetrics.com": ("Kissmetrics", "analytics"),
    "mouseflow.com": ("Mouseflow", "session_replay"),
    "yandex.ru": ("Yandex Metrica", "analytics"),
    "mc.yandex.ru": ("Yandex Metrica", "analytics"),
    "snowplowanalytics.com": ("Snowplow", "analytics"),
    "newrelic.com": ("New Relic", "analytics"),
    "nr-data.net": ("New Relic", "analytics"),
    # --- Advertising ---
    "doubleclick.net": ("Google DoubleClick", "ads"),
    "googlesyndication.com": ("Google AdSense", "ads"),
    "googleadservices.com": ("Google Ads", "ads"),
    "google.com": ("Google (ads/misc)", "ads"),
    "facebook.com": ("Facebook Pixel", "ads"),
    "facebook.net": ("Facebook Pixel", "ads"),
    "fbcdn.net": ("Facebook", "ads"),
    "connect.facebook.net": ("Facebook Pixel", "ads"),
    "ads-twitter.com": ("Twitter Ads", "ads"),
    "t.co": ("Twitter", "ads"),
    "tiktok.com": ("TikTok Pixel", "ads"),
    "analytics.tiktok.com": ("TikTok Pixel", "ads"),
    "bing.com": ("Microsoft Ads", "ads"),
    "bat.bing.com": ("Microsoft UET", "ads"),
    "criteo.com": ("Criteo", "ads"),
    "criteo.net": ("Criteo", "ads"),
    "adroll.com": ("AdRoll", "ads"),
    "taboola.com": ("Taboola", "ads"),
    "outbrain.com": ("Outbrain", "ads"),
    "pubmatic.com": ("PubMatic", "ads"),
    "rubiconproject.com": ("Magnite/Rubicon", "ads"),
    "scorecardresearch.com": ("Comscore", "ads"),
    "adsrvr.org": ("The Trade Desk", "ads"),
    "pinterest.com": ("Pinterest Tag", "ads"),
    "linkedin.com": ("LinkedIn Insight", "ads"),
    "licdn.com": ("LinkedIn", "ads"),
    "snapchat.com": ("Snap Pixel", "ads"),
    "sc-static.net": ("Snap", "ads"),
    "reddit.com": ("Reddit Pixel", "ads"),
    "redditstatic.com": ("Reddit Pixel", "ads"),
    # --- Session replay / heatmaps ---
    "hotjar.com": ("Hotjar", "session_replay"),
    "hotjar.io": ("Hotjar", "session_replay"),
    "clarity.ms": ("Microsoft Clarity", "session_replay"),
    "fullstory.com": ("FullStory", "session_replay"),
    "logrocket.com": ("LogRocket", "session_replay"),
    "logrocket.io": ("LogRocket", "session_replay"),
    "smartlook.com": ("Smartlook", "session_replay"),
    "inspectlet.com": ("Inspectlet", "session_replay"),
    "sessioncam.com": ("SessionCam", "session_replay"),
    "contentsquare.net": ("Contentsquare", "session_replay"),
    # --- CDP / tag managers ---
    "googletagmanager.com": ("Google Tag Manager", "tagmanager"),
    "tealiumiq.com": ("Tealium", "cdp"),
    "mparticle.com": ("mParticle", "cdp"),
    "rudderstack.com": ("RudderStack", "cdp"),
    "ensighten.com": ("Ensighten", "tagmanager"),
    "intercom.io": ("Intercom", "cdp"),
    "intercomcdn.com": ("Intercom", "cdp"),
}


def _registrable(host: str) -> str:
    parts = host.lower().strip(".").split(".")
    if len(parts) <= 2:
        return ".".join(parts)
    return ".".join(parts[-2:])


def match_tracker(host: str) -> tuple[str, str] | None:
    """Return (service, category) if the host belongs to a known tracker."""
    host = host.lower().strip(".")
    # Exact / subdomain match against full keys first (most specific).
    for domain, info in TRACKERS.items():
        if host == domain or host.endswith("." + domain):
            return info
    # Fall back to registrable domain.
    return TRACKERS.get(_registrable(host))


def registrable_domain(host: str) -> str:
    return _registrable(host)
