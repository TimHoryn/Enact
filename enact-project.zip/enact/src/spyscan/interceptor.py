"""Browser-level request interception (page.route): capture, inspect and modify
requests/responses in flight — the browser equivalent of a MITM proxy, without
leaving our own scripts.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Capture:
    url_contains: str
    requests: list[dict] = field(default_factory=list)
    responses: list[dict] = field(default_factory=list)

    def matched(self) -> bool:
        return bool(self.responses)

    def last_response(self) -> dict | None:
        return self.responses[-1] if self.responses else None


def install_capture(page, url_contains: str, body_override: str | None = None,
                    header_override: dict[str, str] | None = None) -> Capture:
    """Record requests/responses whose URL contains ``url_contains``. Optionally
    rewrite the outgoing request body/headers (modify-in-flight)."""
    cap = Capture(url_contains=url_contains)

    def route_handler(route):
        req = route.request
        if url_contains in req.url:
            overrides: dict[str, Any] = {}
            if body_override is not None:
                overrides["post_data"] = body_override
            if header_override:
                headers = dict(req.headers)
                headers.update({k.lower(): v for k, v in header_override.items()})
                overrides["headers"] = headers
            cap.requests.append({"url": req.url, "method": req.method, "post_data": req.post_data})
            route.continue_(**overrides)
        else:
            route.continue_()

    def on_response(response):
        if url_contains in response.url:
            try:
                body = response.text()
            except Exception:
                body = None
            cap.responses.append({"url": response.url, "status": response.status, "body": body})

    page.route("**/*", route_handler)
    page.on("response", on_response)
    return cap
