"""Privacy x-ray: which third-party trackers the site talks to, which sensitive
values leak to them (or into URLs), and how safe the cookies are.

Purely defensive and self-contained — it only inspects the capture.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import unquote

from .model import Session
from .trackers import match_tracker, registrable_domain

# kind -> (compiled regex, severity)
_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"), "critical"),
    ("aws_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "critical"),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"), "critical"),
    ("stripe_secret", re.compile(r"\bsk_live_[0-9a-zA-Z]{10,}\b"), "critical"),
    ("github_token", re.compile(r"\bgh[pousr]_[0-9A-Za-z]{30,}\b"), "high"),
    ("stripe_pub", re.compile(r"\bpk_live_[0-9a-zA-Z]{10,}\b"), "high"),
    ("email", re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"), "medium"),
    # Phone: require either an international '+' or separator grouping, so bare
    # digit runs (timestamps, ids, base64) don't masquerade as phone numbers.
    ("phone", re.compile(
        r"(?<![\w.])(?:\+\d[\d\-\s().]{6,13}\d|\(?\d{2,4}\)?[\s\-]\d{2,4}[\s\-]\d{2,4}(?:[\s\-]\d{1,4})?)(?![\w.])"
    ), "medium"),
]

# Generic "this param name is a secret" detector for values in URLs.
_SECRET_PARAM_RE = re.compile(r"(api[_-]?key|secret|token|password|passwd|auth|session)", re.IGNORECASE)


@dataclass
class TrackerHit:
    host: str
    service: str
    category: str
    count: int = 0
    where: list[str] = field(default_factory=list)


@dataclass
class Leak:
    kind: str
    severity: str        # critical | high | medium
    value_preview: str
    where: str           # "METHOD /path"
    to_host: str
    third_party: bool
    in_url: bool = False


@dataclass
class CookieAudit:
    name: str
    secure: bool
    http_only: bool
    same_site: str | None
    score: int
    issues: list[str] = field(default_factory=list)


@dataclass
class PrivacyReport:
    trackers: list[TrackerHit] = field(default_factory=list)
    leaks: list[Leak] = field(default_factory=list)
    cookies: list[CookieAudit] = field(default_factory=list)


def _primary_domain(session: Session) -> str | None:
    hosts = Counter()
    for e in session.entries:
        host = e.request.host
        if host and not match_tracker(host):
            hosts[registrable_domain(host)] += 1
    return hosts.most_common(1)[0][0] if hosts else None


def _first_party_domains(session: Session) -> set[str]:
    """Every non-tracker registrable domain the capture talked to is treated as
    first-party. This keeps cross-subsite traffic (and multi-site captures) from
    being miscounted as third-party leaks — only trackers and genuinely foreign
    domains count as third-party."""
    doms: set[str] = set()
    for e in session.entries:
        host = e.request.host
        if host and not match_tracker(host):
            doms.add(registrable_domain(host))
    return doms


def _preview(value: str) -> str:
    value = value.strip()
    if len(value) <= 12:
        return value
    return value[:6] + "…" + value[-4:]


def _score_cookie(c) -> tuple[int, list[str]]:
    score = 100
    issues: list[str] = []
    is_session = bool(c.http_only) or re.search(r"(session|sess|sid|auth|login)", c.name, re.IGNORECASE)
    if not c.secure:
        score -= 30
        issues.append("no Secure flag — cookie may leak over HTTP")
    if not c.http_only:
        if is_session and not re.search(r"(csrf|xsrf)", c.name, re.IGNORECASE):
            score -= 25
            issues.append("no HttpOnly — readable from JS (XSS theft risk)")
        else:
            score -= 10
            issues.append("no HttpOnly")
    ss = (c.same_site or "").lower()
    if ss in ("", "none"):
        score -= 20
        issues.append("SameSite unset/None — CSRF risk")
    elif ss == "lax":
        score -= 5
        issues.append("SameSite=Lax (not Strict)")
    return max(0, score), issues


def audit_privacy(session: Session) -> PrivacyReport:
    report = PrivacyReport()
    first_party = _first_party_domains(session)
    tracker_hits: dict[str, TrackerHit] = {}
    cookies: dict[str, CookieAudit] = {}

    for e in session.entries:
        req = e.request
        where = f"{req.method} {req.path}"
        host = req.host
        is_tracker = match_tracker(host)
        third_party = bool(is_tracker) or (
            bool(first_party) and registrable_domain(host) not in first_party
        )

        if is_tracker:
            service, category = is_tracker
            hit = tracker_hits.get(host)
            if not hit:
                hit = TrackerHit(host=host, service=service, category=category)
                tracker_hits[host] = hit
            hit.count += 1
            if where not in hit.where:
                hit.where.append(where)

        # --- Leaks ---
        url_text = unquote(req.url)
        header_text = " ".join(v for _, v in req.headers.items() if _.lower() != "cookie")
        body_text = req.post_data or ""

        # Secrets/PII reaching a third-party host (URL + headers + body).
        if third_party:
            scanned = f"{url_text}\n{header_text}\n{unquote(body_text)}"
            report.leaks.extend(
                _scan(scanned, where, host, third_party=True, in_url=False, only_in=url_text)
            )
        # Secrets sitting in ANY URL (bad practice regardless of host).
        report.leaks.extend(_scan_url_secrets(req, where, host, third_party))

        # --- Cookies ---
        for c in e.response.set_cookies:
            score, issues = _score_cookie(c)
            cookies[c.name] = CookieAudit(c.name, c.secure, c.http_only, c.same_site, score, issues)

    report.trackers = list(tracker_hits.values())
    report.cookies = list(cookies.values())
    report.leaks = _dedup(report.leaks)
    return report


def _scan(text: str, where: str, host: str, third_party: bool, in_url: bool, only_in: str) -> list[Leak]:
    leaks: list[Leak] = []
    for kind, rx, sev in _PATTERNS:
        for m in rx.finditer(text):
            val = m.group(0)
            leaks.append(Leak(
                kind=kind, severity=sev, value_preview=_preview(val),
                where=where, to_host=host, third_party=third_party,
                in_url=val in only_in,
            ))
    return leaks


def _scan_url_secrets(req, where: str, host: str, third_party: bool) -> list[Leak]:
    leaks: list[Leak] = []
    for name, values in req.query.items():
        for value in values:
            matched = False
            for kind, rx, sev in _PATTERNS:
                if rx.fullmatch(value) or rx.search(value):
                    leaks.append(Leak(kind, sev, _preview(value), where, host, third_party, in_url=True))
                    matched = True
                    break
            if not matched and _SECRET_PARAM_RE.search(name) and len(value) >= 8:
                leaks.append(Leak("secret_in_url", "high", _preview(value), where, host, third_party, in_url=True))
    return leaks


def _dedup(leaks: list[Leak]) -> list[Leak]:
    seen = set()
    out = []
    order = {"critical": 0, "high": 1, "medium": 2}
    for l in sorted(leaks, key=lambda x: order.get(x.severity, 9)):
        key = (l.kind, l.value_preview, l.where, l.in_url)
        if key not in seen:
            seen.add(key)
            out.append(l)
    return out
