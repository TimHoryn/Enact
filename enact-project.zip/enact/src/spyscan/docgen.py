"""Generate human- and agent-readable Markdown reports from an assembled
session document (the output of ``export.build_session_json``)."""

from __future__ import annotations

_PARAM_EN = {
    "pagination": "pagination (paging)",
    "filter": "filter",
    "search": "search",
    "sort": "sort",
    "identifier": "identifier",
    "parameter": "parameter",
}


def _auth(ep) -> str:
    bits = []
    if ep.get("needs_auth"):
        bits.append("auth")
    if ep.get("needs_csrf"):
        bits.append("csrf")
    if ep.get("needs_browser"):
        bits.append("browser")
    return ", ".join(bits) or "—"


def build_agent_markdown(doc: dict) -> str:
    m = doc.get("_meta", {})
    site = m.get("site", "?")
    api_map = doc.get("api_map", {})
    cat = doc.get("params_catalog", {})
    blockers = doc.get("blockers_detected", [])
    out: list[str] = []
    out.append(f"# spyscan — what you can do with this session\n")
    out.append(f"Authorized session for **{site}** ({m.get('entry_count')} requests). "
               "You (the agent) can replay these requests as the user.\n")
    out.append("## How to use me (3 ways)\n")
    out.append("1. **Python facade** — simplest: `from spyscan.agent import Spyscan; "
               "sp = Spyscan.open('<dir>'); sp.call('GET /path', page=2)`. Methods: "
               "`operations()`, `find('query')`, `call(...)`, `collect(...)`.\n"
               "2. **tools.json** — ready function-calling schemas (one tool per operation); "
               "hand them to an LLM as tools, names = operation ids.\n"
               "3. **agent.json** — machine-readable manifest: operations, params, returns, rules.\n")
    out.append("## How to replay (low level)\n")
    out.append("```python\n"
               "from spyscan.model import Session\n"
               "from spyscan.browser import BrowserSession\n"
               "from spyscan.replay import ReplayEngine\n\n"
               "s = Session.load('capture/session.har')\n"
               "b = BrowserSession(storage_state='capture/storage_state.json',\n"
               "                   headless=True, start_url='https://<origin>/').start()\n"
               "eng = ReplayEngine(b, s)\n"
               "r = eng.replay('GET /cloud/v2/instances', edits={'query': {'page': 2}})\n"
               "# writes: eng.replay('POST /...', allow_writes=True)  # dry-run by default\n"
               "```\n")
    out.append("Rules: GET — go ahead; POST/PUT/DELETE — only with `allow_writes=True`. "
               "CAPTCHA/2FA are never bypassed (see blockers). The engine refreshes "
               "cookies/one-time tokens and re-auths on 401 by itself.\n")

    tasks = doc.get("tasks", [])
    if tasks:
        out.append("## Ready tasks (outcomes, not just endpoints)\n")
        for t in tasks[:30]:
            out.append(f"- **{t['title']}** — `{t['command']}`  \n  <sub>{t['note']}</sub>")
        out.append("")

    out.append("## Available requests (map)\n")
    for host, eps in api_map.items():
        out.append(f"\n### {host}\n")
        out.append("| method+path | needs | returns | editable |\n|---|---|---|---|")
        for ep in eps:
            params = ", ".join(f"`{p['name']}`({p['type']})" for p in ep["params"]) or "—"
            ret = ep.get("returns") or "—"
            out.append(f"| `{ep['method']} {ep['path']}` | {_auth(ep)} | `{ret}` | {params} |")
        out.append("")

    if cat:
        out.append("## Parameters you can change\n")
        for ptype, items in cat.items():
            names = ", ".join(f"`{it['name']}`(e.g. {it['example']})" for it in items[:12])
            out.append(f"- **{_PARAM_EN.get(ptype, ptype)}**: {names}")
        out.append("")

    if blockers:
        out.append("## Blockers — stop here, ask a human\n")
        for b in blockers:
            out.append(f"- {b['type']} / {b['service']} (×{b.get('count',1)})")
        out.append("")
    return "\n".join(out)


def build_human_markdown(doc: dict) -> str:
    m = doc.get("_meta", {})
    p = doc.get("privacy", {})
    api_map = doc.get("api_map", {})
    cat = doc.get("params_catalog", {})
    eps = doc.get("endpoints", [])
    blockers = doc.get("blockers_detected", [])
    out: list[str] = []
    out.append(f"# Capture report — {m.get('site','?')}\n")
    out.append(f"Recorded {m.get('recorded_at','')[:19].replace('T',' ')}. "
               f"**{m.get('entry_count')} requests** total, **{len(eps)} distinct endpoints**, "
               f"**{sum(1 for e in eps if e.get('needs_auth'))}** authorized.\n")

    out.append("## What this means in plain words\n")
    out.append("We recorded your browser session and worked out which requests the site makes "
               "to its API. Those requests can now be replayed as you (with your cookies) — "
               "paginate, filter, collect data — without clicking by hand.\n")

    tasks = doc.get("tasks", [])
    if tasks:
        out.append("## What you can do\n")
        labels = {"collect": "📊 Export to a table", "write": "✍️ Changes/actions", "read": "📄 Fetch an object"}
        for kind in ("collect", "write", "read"):
            ts = [t for t in tasks if t["kind"] == kind]
            if not ts:
                continue
            out.append(f"\n**{labels[kind]}**")
            for t in ts[:12]:
                out.append(f"- {t['title']} — `{t['command']}`")
        out.append("")

    out.append("## Request map\n")
    for host, hep in api_map.items():
        auth_n = sum(1 for e in hep if e["needs_auth"])
        out.append(f"\n**{host}** — {len(hep)} endpoints ({auth_n} authorized)")
        for ep in hep[:40]:
            ret = f" → `{ep['returns']}`" if ep.get("returns") else ""
            out.append(f"- `{ep['method']} {ep['path']}`{ret}")
        if len(hep) > 40:
            out.append(f"- …and {len(hep)-40} more")
    out.append("")

    if cat:
        out.append("## What you can change\n")
        for ptype, items in cat.items():
            names = ", ".join(f"`{it['name']}`" for it in items[:15])
            out.append(f"- **{_PARAM_EN.get(ptype, ptype)}**: {names}")
        out.append("")

    out.append("## Security & privacy\n")
    out.append(f"- Trackers: {', '.join(t['service'] for t in p.get('trackers', [])) or 'none'}")
    leaks = [l for l in p.get("leaks", []) if l.get("third_party")]
    out.append(f"- External leaks: {len(leaks)} (signatures, false positives possible)")
    weak = [c for c in p.get("cookies", []) if c["score"] < 70]
    out.append(f"- Weak cookies: {len(weak)} of {len(p.get('cookies', []))}")
    if blockers:
        out.append(f"- Blockers (stop for a human): "
                   + ", ".join(f"{b['service']}×{b.get('count',1)}" for b in blockers))
    out.append("")
    return "\n".join(out)
