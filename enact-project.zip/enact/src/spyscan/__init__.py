"""spyscan — record your own authorized browser session, understand its auth
chains, and replay/modify any request through a real browser.

All safety boundaries live in the design: replay goes through a real browser
(authentic fingerprint, no spoofing), CAPTCHAs are detected and handed back to
the human (never bypassed), writes are dry-run by default, and nothing talks to
third-party services.
"""

__version__ = "0.1.0"
