"""Core data model for a captured session.

Everything downstream (extractor, analyzer, provenance, privacy, replay) operates
on these objects. The canonical on-disk capture format is HAR 1.2 — the standard
browser archive format, which is also what Playwright emits via
``record_har_path``. ``Session.from_har`` parses that into typed objects.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Iterable
from urllib.parse import parse_qs, urlparse


def _norm(name: str) -> str:
    return name.lower().strip()


@dataclass
class Headers:
    """Ordered, case-insensitive multi-map of header name -> value.

    Order and duplicates are preserved (they matter for the browser replay
    path and for fingerprint-faithful requests); lookups are case-insensitive.
    """

    pairs: list[tuple[str, str]] = field(default_factory=list)

    def get(self, name: str, default: str | None = None) -> str | None:
        key = _norm(name)
        for k, v in self.pairs:
            if _norm(k) == key:
                return v
        return default

    def get_all(self, name: str) -> list[str]:
        key = _norm(name)
        return [v for k, v in self.pairs if _norm(k) == key]

    def has(self, name: str) -> bool:
        return self.get(name) is not None

    def items(self) -> list[tuple[str, str]]:
        return list(self.pairs)

    def names(self) -> list[str]:
        return [k for k, _ in self.pairs]

    def to_dict(self) -> dict[str, str]:
        # Last value wins, like a normal header dict.
        out: dict[str, str] = {}
        for k, v in self.pairs:
            out[k] = v
        return out

    @classmethod
    def from_har(cls, entries: Iterable[dict]) -> "Headers":
        return cls([(e.get("name", ""), e.get("value", "")) for e in entries or []])


@dataclass
class Cookie:
    name: str
    value: str
    domain: str | None = None
    path: str | None = None
    secure: bool = False
    http_only: bool = False
    same_site: str | None = None
    expires: float | None = None

    @classmethod
    def from_har(cls, e: dict) -> "Cookie":
        return cls(
            name=e.get("name", ""),
            value=e.get("value", ""),
            domain=e.get("domain"),
            path=e.get("path"),
            secure=bool(e.get("secure", False)),
            http_only=bool(e.get("httpOnly", False)),
            same_site=e.get("sameSite"),
            expires=_parse_expires(e.get("expires")),
        )


def _parse_expires(raw: Any) -> float | None:
    if raw in (None, "", -1):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    # HAR stores ISO 8601 strings; best-effort parse.
    try:
        from datetime import datetime

        return datetime.fromisoformat(str(raw).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def _maybe_json(text: str | None, mime: str | None) -> Any | None:
    if not text:
        return None
    looks_json = (mime and "json" in mime.lower()) or text.lstrip()[:1] in ("{", "[")
    if not looks_json:
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


@dataclass
class CapturedRequest:
    method: str
    url: str
    headers: Headers = field(default_factory=Headers)
    query: dict[str, list[str]] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    post_data: str | None = None
    post_json: Any | None = None
    resource_type: str | None = None

    @property
    def origin(self) -> str:
        p = urlparse(self.url)
        return f"{p.scheme}://{p.netloc}"

    @property
    def host(self) -> str:
        return urlparse(self.url).netloc

    @property
    def path(self) -> str:
        return urlparse(self.url).path

    @property
    def is_write(self) -> bool:
        return self.method.upper() in ("POST", "PUT", "PATCH", "DELETE")

    @classmethod
    def from_har(cls, r: dict) -> "CapturedRequest":
        url = r.get("url", "")
        post = r.get("postData") or {}
        text = post.get("text")
        mime = post.get("mimeType")
        query = {k: v for k, v in parse_qs(urlparse(url).query).items()}
        cookies = {c.get("name", ""): c.get("value", "") for c in r.get("cookies", [])}
        return cls(
            method=r.get("method", "GET"),
            url=url,
            headers=Headers.from_har(r.get("headers", [])),
            query=query,
            cookies=cookies,
            post_data=text,
            post_json=_maybe_json(text, mime),
            resource_type=r.get("_resourceType"),
        )


@dataclass
class CapturedResponse:
    status: int
    headers: Headers = field(default_factory=Headers)
    set_cookies: list[Cookie] = field(default_factory=list)
    body_text: str | None = None
    body_json: Any | None = None
    content_type: str | None = None
    redirect_url: str | None = None

    @classmethod
    def from_har(cls, r: dict) -> "CapturedResponse":
        content = r.get("content") or {}
        text = content.get("text")
        mime = content.get("mimeType")
        headers = Headers.from_har(r.get("headers", []))
        return cls(
            status=int(r.get("status", 0) or 0),
            headers=headers,
            set_cookies=[Cookie.from_har(c) for c in r.get("cookies", [])],
            body_text=text,
            body_json=_maybe_json(text, mime),
            content_type=mime or headers.get("content-type"),
            redirect_url=r.get("redirectURL") or None,
        )


@dataclass
class Entry:
    request: CapturedRequest
    response: CapturedResponse
    started_at: str | None = None
    index: int = 0

    @classmethod
    def from_har(cls, e: dict, index: int = 0) -> "Entry":
        return cls(
            request=CapturedRequest.from_har(e.get("request", {})),
            response=CapturedResponse.from_har(e.get("response", {})),
            started_at=e.get("startedDateTime"),
            index=index,
        )


@dataclass
class Session:
    entries: list[Entry] = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    @classmethod
    def from_har(cls, har: dict | str) -> "Session":
        if isinstance(har, str):
            har = json.loads(har)
        log = har.get("log", har)
        raw_entries = log.get("entries", [])
        entries = [Entry.from_har(e, i) for i, e in enumerate(raw_entries)]
        meta = {
            "creator": (log.get("creator") or {}).get("name"),
            "entry_count": len(entries),
        }
        return cls(entries=entries, meta=meta)

    @classmethod
    def load(cls, path: str) -> "Session":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_har(json.load(fh))

    def before(self, index: int) -> list[Entry]:
        """Entries that happened strictly before the given index (upstream)."""
        return [e for e in self.entries if e.index < index]


@dataclass
class ReplayRequest:
    """A request about to be (re)issued. Mutable, order-preserving, decoupled
    from the captured original so edits never touch the capture."""

    method: str
    url: str
    headers: list[tuple[str, str]] = field(default_factory=list)
    cookies: dict[str, str] = field(default_factory=dict)
    body: str | None = None

    @classmethod
    def from_request(cls, req: "CapturedRequest") -> "ReplayRequest":
        return cls(
            method=req.method,
            url=req.url,
            headers=[(k, v) for k, v in req.headers.items()],
            cookies=dict(req.cookies),
            body=req.post_data,
        )

    @property
    def is_write(self) -> bool:
        return self.method.upper() in ("POST", "PUT", "PATCH", "DELETE")

    def header(self, name: str) -> str | None:
        for k, v in self.headers:
            if k.lower() == name.lower():
                return v
        return None
