"""Live recording with an in-browser control panel.

Opens a real browser with a floating "⏹ Stop" button injected on every page.
You log in and browse; clicking Stop (or closing the window) ends recording,
assembles session.json, starts the local server and opens the report/3D view in
a fresh browser window — all in the same machine, nothing external.
"""

from __future__ import annotations

import json
import os
import threading
import time

from playwright.sync_api import sync_playwright

from .browser import _ACTION_LOGGER
from .export import build_openapi, build_session_json
from .model import Session

# Floating control panel injected into every page.
_PANEL = r"""
(() => {
  function mount() {
    if (document.getElementById('__spyscan_panel')) return;
    if (!document.body) return;
    const d = document.createElement('div');
    d.id = '__spyscan_panel';
    d.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;'
      + 'background:#101621ee;color:#d7dce5;border:1px solid #33415c;border-radius:10px;'
      + 'padding:8px 10px;font:13px system-ui,sans-serif;display:flex;align-items:center;gap:10px;'
      + 'box-shadow:0 6px 20px #0008';
    d.innerHTML = '<span style="color:#ff5c6c">●</span><b>spyscan</b>'
      + '<span id="__spyscan_t" style="color:#8b97ad">REC</span>'
      + '<button id="__spyscan_stop" style="background:#ff3b4e;color:#fff;border:0;'
      + 'border-radius:6px;padding:4px 10px;cursor:pointer;font:inherit">⏹ Stop</button>';
    document.body.appendChild(d);
    const t0 = Date.now();
    setInterval(() => { const s=((Date.now()-t0)/1000)|0; const el=document.getElementById('__spyscan_t');
      if(el) el.textContent='REC '+(s/60|0)+':'+String(s%60).padStart(2,'0'); }, 1000);
    document.getElementById('__spyscan_stop').onclick = () => {
      d.querySelector('span').style.color = '#8b97ad';
      document.getElementById('__spyscan_t').textContent = 'stopping…';
      if (window.__spyscan_stop) window.__spyscan_stop();
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
  setInterval(mount, 1500); // re-mount after SPA navigations
})();
"""


class LiveRecorder:
    def __init__(self, start_url: str, out_dir: str, report_port: int = 8088):
        self.start_url = start_url
        self.out_dir = out_dir
        self.report_port = report_port
        self._stop = threading.Event()

    def run(self) -> dict:
        os.makedirs(self.out_dir, exist_ok=True)
        har = os.path.join(self.out_dir, "session.har")
        pw = sync_playwright().start()
        browser = pw.chromium.launch(headless=False)
        ctx = browser.new_context(record_har_path=har, record_har_content="embed")
        ctx.expose_binding("__spyscan_stop", lambda source: self._stop.set())
        ctx.expose_binding("__spyact", lambda source, data: None)  # action hook placeholder
        ctx.add_init_script(_ACTION_LOGGER)
        ctx.add_init_script(_PANEL)
        page = ctx.new_page()
        page.goto(self.start_url)
        print("READY: recording. Click ⏹ Stop in the browser to finish.", flush=True)

        # Pump events until the in-browser Stop is clicked or the window closes.
        closed = {"v": False}
        browser.on("disconnected", lambda: closed.__setitem__("v", True))
        while not self._stop.is_set() and not closed["v"]:
            try:
                page.wait_for_timeout(300)
            except Exception:
                break

        try:
            if not closed["v"]:
                ctx.storage_state(path=os.path.join(self.out_dir, "storage_state.json"))
        except Exception as e:
            print("storage warn:", e, flush=True)
        try:
            ctx.close()  # flush HAR
            browser.close()
        except Exception:
            pass
        pw.stop()
        print("STOPPED: recording saved, building report…", flush=True)

        session = Session.load(har)
        doc = build_session_json(session)
        with open(os.path.join(self.out_dir, "session.json"), "w", encoding="utf-8") as fh:
            json.dump(doc, fh, ensure_ascii=False, indent=2)
        with open(os.path.join(self.out_dir, "openapi.json"), "w", encoding="utf-8") as fh:
            json.dump(build_openapi(session), fh, ensure_ascii=False, indent=2)
        print("REPORT_READY", flush=True)
        return {"out_dir": self.out_dir, "entries": len(session.entries)}

    def serve_and_open(self) -> None:
        import uvicorn

        from .server import create_app

        app = create_app(self.out_dir)
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=self.report_port, log_level="error"))
        threading.Thread(target=server.run, daemon=True).start()
        for _ in range(100):
            if server.started:
                break
            time.sleep(0.05)
        url = f"http://127.0.0.1:{self.report_port}/"
        print(f"REPORT_URL {url}", flush=True)
        pw = sync_playwright().start()
        browser = pw.chromium.launch(headless=False)
        page = browser.new_context().new_page()
        try:
            # Don't wait for "load": the optional 3D CDN scripts may be slow.
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            print(f"goto note: {e}", flush=True)
        # Keep the report window open until the user closes it.
        done = {"v": False}
        browser.on("disconnected", lambda: done.__setitem__("v", True))
        while not done["v"]:
            try:
                page.wait_for_timeout(500)
            except Exception:
                break
        pw.stop()
