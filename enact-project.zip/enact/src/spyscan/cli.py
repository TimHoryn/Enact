"""spyscan command-line interface.

    spyscan record <url> [--out DIR] [--headless]
    spyscan analyze <capture_dir>
    spyscan serve <capture_dir> [--port 8088]
    spyscan replay <capture_dir> --endpoint "GET /api/orders" \
            [--query k=v ...] [--body k=v ...] [--header k=v ...] \
            [--allow-writes] [--trigger "#place"]
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from .export import build_openapi, build_session_json
from .model import Session


def _kv(pairs: list[str] | None) -> dict:
    out: dict = {}
    for p in pairs or []:
        if "=" not in p:
            continue
        k, v = p.split("=", 1)
        if v.lower() in ("null", "none", ""):
            out[k] = None
        elif v.isdigit():
            out[k] = int(v)
        else:
            out[k] = v
    return out


def cmd_record(args) -> int:
    from .recorder import finish, new_recording

    sess = new_recording(args.url, args.out, headless=args.headless).start()
    print(f"Recording {args.url}. Log in / click around, then press Enter to stop…")
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        pass
    paths = finish(sess, args.out)
    print("Saved:", json.dumps(paths, ensure_ascii=False, indent=2))
    return 0


def cmd_analyze(args) -> int:
    har = os.path.join(args.capture_dir, "session.har")
    session = Session.load(har)
    doc = build_session_json(session)
    with open(os.path.join(args.capture_dir, "session.json"), "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(args.capture_dir, "openapi.json"), "w", encoding="utf-8") as fh:
        json.dump(build_openapi(session), fh, ensure_ascii=False, indent=2)
    from .docgen import build_agent_markdown, build_human_markdown
    from .agentkit import build_manifest, build_tool_schemas
    with open(os.path.join(args.capture_dir, "AGENT.md"), "w", encoding="utf-8") as fh:
        fh.write(build_agent_markdown(doc))
    with open(os.path.join(args.capture_dir, "REPORT.md"), "w", encoding="utf-8") as fh:
        fh.write(build_human_markdown(doc))
    with open(os.path.join(args.capture_dir, "agent.json"), "w", encoding="utf-8") as fh:
        json.dump(build_manifest(doc), fh, ensure_ascii=False, indent=2)
    with open(os.path.join(args.capture_dir, "tools.json"), "w", encoding="utf-8") as fh:
        json.dump(build_tool_schemas(doc), fh, ensure_ascii=False, indent=2)
    p = doc["privacy"]
    print(f"Site: {doc['_meta']['site']}  requests: {doc['_meta']['entry_count']}")
    print(f"Endpoints: {len(doc['endpoints'])}  trackers: {len(p['trackers'])}  leaks: {len(p['leaks'])}")
    for b in doc["blockers_detected"]:
        print(f"  ⚠ blocker: {b['type']} ({b['service']}) @ {b['where']}")
    print(f"Files in {args.capture_dir}: session.json · openapi.json · AGENT.md · REPORT.md · agent.json · tools.json")
    print("⚠ The capture stores live cookies/tokens in clear text. Before sharing with anyone — `spyscan scrub`.")
    return 0


def _origin_of(session) -> str | None:
    if not session.entries:
        return None
    return session.entries[0].request.origin + "/"


def _browser_for(args, session):
    from .browser import BrowserSession
    storage = os.path.join(args.capture_dir, "storage_state.json")
    return BrowserSession(storage_state=storage if os.path.exists(storage) else None,
                          headless=True, start_url=_origin_of(session)).start()


def cmd_action(args) -> int:
    from .tasks import run_actions
    actions_path = os.path.join(args.capture_dir, "actions.json")
    if not os.path.exists(actions_path):
        print("No actions.json in the capture (record with record/live).", file=sys.stderr)
        return 1
    actions = json.load(open(actions_path, encoding="utf-8"))
    overrides = _kv(args.set)
    if not args.allow_writes:
        print("Dry-run (no --allow-writes). Steps that would run:")
        for a in actions:
            sel = a.get("selector")
            if not sel or sel == "document":
                continue
            v = overrides.get(sel, a.get("value"))
            print(f"  {a.get('type')} {sel}" + (f" = {v}" if a.get("type") == "fill" else ""))
        return 0
    session = Session.load(os.path.join(args.capture_dir, "session.har"))
    sess = _browser_for(args, session)
    try:
        r = run_actions(sess, actions, overrides=overrides, capture_path=args.capture,
                        start_url=_origin_of(session))
        print("Done:", "; ".join(r["steps"]))
        if r["response"]:
            print(f"Response: {r['response']['status']} {r['response']['body'][:500]}")
    finally:
        sess.stop()
    return 0


def cmd_bulk(args) -> int:
    from .replay import ReplayEngine
    from .tasks import bulk
    session = Session.load(os.path.join(args.capture_dir, "session.har"))
    if os.path.exists(args.items):
        items = json.load(open(args.items, encoding="utf-8"))
    else:
        items = json.loads(args.items)
    sess = _browser_for(args, session)
    try:
        eng = ReplayEngine(sess, session, allow_writes=args.allow_writes)
        res = bulk(eng, args.endpoint, items, allow_writes=args.allow_writes)
        ok = sum(1 for r in res if r["status"] in (200, 201))
        dry = sum(1 for r in res if r["dry_run"])
        print(f"Total: {len(res)} · ok: {ok} · dry-run: {dry}")
        for r in res:
            print(f"  {r['edits']} → {'dry-run' if r['dry_run'] else r['status']}")
    finally:
        sess.stop()
    return 0


def cmd_monitor(args) -> int:
    from .replay import ReplayEngine
    from .tasks import monitor
    session = Session.load(os.path.join(args.capture_dir, "session.har"))
    baseline = None
    bf = args.baseline or os.path.join(args.capture_dir, "monitor-baseline.txt")
    if os.path.exists(bf):
        baseline = open(bf, encoding="utf-8").read().strip()
    sess = _browser_for(args, session)
    try:
        eng = ReplayEngine(sess, session)
        changed, digest = monitor(eng, args.endpoint, baseline)
    finally:
        sess.stop()
    with open(bf, "w", encoding="utf-8") as fh:
        fh.write(digest)
    if baseline is None:
        print(f"Baseline snapshot saved ({bf}). Run again later to see changes.")
    else:
        print("CHANGED ✓" if changed else "no change")
    return 0


def cmd_scrub(args) -> int:
    from .safety import scrub_capture
    c = scrub_capture(args.capture_dir)
    print(f"Scrubbed: session fields {c['session_fields']}, storage cookies {c['storage_cookies']}")
    for o in c["outputs"]:
        print(f"  safe copy: {o}")
    return 0


def cmd_live(args) -> int:
    from .live import LiveRecorder
    rec = LiveRecorder(args.url, args.out, report_port=args.port)
    rec.run()
    rec.serve_and_open()
    return 0


def cmd_report(args) -> int:
    from .live import LiveRecorder
    rec = LiveRecorder("about:blank", args.capture_dir, report_port=args.port)
    rec.serve_and_open()
    return 0


def cmd_serve(args) -> int:
    import uvicorn

    from .server import create_app

    app = create_app(args.capture_dir)
    print(f"spyscan 3D at http://127.0.0.1:{args.port}")
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")
    return 0


def cmd_replay(args) -> int:
    from .browser import BrowserSession
    from .replay import ReplayEngine

    har = os.path.join(args.capture_dir, "session.har")
    storage = os.path.join(args.capture_dir, "storage_state.json")
    session = Session.load(har)
    method, _, path = args.endpoint.partition(" ")
    idx = next((e.index for e in session.entries
                if e.request.method == method and e.request.path == path), None)
    if idx is None:
        print(f"Endpoint not found: {args.endpoint}", file=sys.stderr)
        return 1

    edits: dict = {}
    if args.query:
        edits["query"] = _kv(args.query)
    if args.body:
        edits["body"] = _kv(args.body)
    if args.header:
        edits["headers"] = _kv(args.header)

    start = None
    first = session.entries[0].request.url if session.entries else None
    if first:
        from urllib.parse import urlparse
        u = urlparse(first)
        start = f"{u.scheme}://{u.netloc}/"
    sess = BrowserSession(storage_state=storage if os.path.exists(storage) else None,
                          headless=True, start_url=start).start()
    try:
        engine = ReplayEngine(sess, session, allow_writes=args.allow_writes)
        res = engine.replay(idx, edits=edits or None,
                            allow_writes=args.allow_writes, trigger_selector=args.trigger)
        print(f"tier={res.tier} dry_run={res.dry_run} status={res.status}")
        if res.refreshed:
            print(f"refreshed values: {len(res.refreshed)}")
        if res.note:
            print(res.note)
        if res.body:
            print(res.body[:2000])
    finally:
        sess.stop()
    return 0


def cmd_collect(args) -> int:
    from urllib.parse import urlparse

    from .browser import BrowserSession
    from .replay import ReplayEngine
    from .tasks import collect

    har = os.path.join(args.capture_dir, "session.har")
    storage = os.path.join(args.capture_dir, "storage_state.json")
    session = Session.load(har)
    method, _, path = args.endpoint.partition(" ")
    entry = next((e for e in session.entries
                  if e.request.method == method and e.request.path == path), None)
    if entry is None:
        print(f"Endpoint not found: {args.endpoint}", file=sys.stderr)
        return 1
    origin = entry.request.origin + "/"
    out = args.out or (path.strip("/").split("/")[-1] or "data") + ".csv"
    sess = BrowserSession(storage_state=storage if os.path.exists(storage) else None,
                          headless=True, start_url=origin).start()
    try:
        eng = ReplayEngine(sess, session)
        res = collect(eng, args.endpoint, out_path=out, max_pages=args.max_pages)
        print(f"Rows collected: {res.rows} (pages: {res.pages})")
        if res.keys:
            print(f"Columns: {', '.join(res.keys[:15])}{'…' if len(res.keys) > 15 else ''}")
        if res.out and res.rows:
            print(f"Table written: {res.out}")
    finally:
        sess.stop()
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="spyscan")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("record", help="record a session through the browser")
    r.add_argument("url")
    r.add_argument("--out", default="./capture")
    r.add_argument("--headless", action="store_true")
    r.set_defaults(func=cmd_record)

    a = sub.add_parser("analyze", help="parse HAR into session.json + openapi.json + reports")
    a.add_argument("capture_dir")
    a.set_defaults(func=cmd_analyze)

    s = sub.add_parser("serve", help="serve the 3D visualization")
    s.add_argument("capture_dir")
    s.add_argument("--port", type=int, default=8088)
    s.set_defaults(func=cmd_serve)

    lv = sub.add_parser("live", help="record with an in-browser Stop button + auto report")
    lv.add_argument("url")
    lv.add_argument("--out", default="./capture")
    lv.add_argument("--port", type=int, default=8088)
    lv.set_defaults(func=cmd_live)

    rep = sub.add_parser("report", help="open the capture report in the browser")
    rep.add_argument("capture_dir")
    rep.add_argument("--port", type=int, default=8088)
    rep.set_defaults(func=cmd_report)

    co = sub.add_parser("collect", help="collect a whole resource (all pages) into CSV")
    co.add_argument("capture_dir")
    co.add_argument("endpoint", help='e.g. "GET /cloud/v2/instances"')
    co.add_argument("--out", help="CSV file (default: resource name)")
    co.add_argument("--max-pages", type=int, default=50)
    co.set_defaults(func=cmd_collect)

    ac = sub.add_parser("action", help="replay recorded clicks/forms (with overrides)")
    ac.add_argument("capture_dir")
    ac.add_argument("--set", action="append", help="selector=value to fill into a field")
    ac.add_argument("--capture", help="path whose response to capture (e.g. /api/...)")
    ac.add_argument("--allow-writes", action="store_true", help="actually run (otherwise dry-run)")
    ac.set_defaults(func=cmd_action)

    bk = sub.add_parser("bulk", help="bulk-replay a write endpoint over a list of data")
    bk.add_argument("capture_dir")
    bk.add_argument("--endpoint", required=True)
    bk.add_argument("--items", required=True, help="JSON file or inline JSON: a list of edits")
    bk.add_argument("--allow-writes", action="store_true")
    bk.set_defaults(func=cmd_bulk)

    mo = sub.add_parser("monitor", help="snapshot an endpoint and compare to a baseline")
    mo.add_argument("capture_dir")
    mo.add_argument("--endpoint", required=True)
    mo.add_argument("--baseline", help="baseline snapshot file")
    mo.set_defaults(func=cmd_monitor)

    sc = sub.add_parser("scrub", help="make safe copies without cookies/tokens")
    sc.add_argument("capture_dir")
    sc.set_defaults(func=cmd_scrub)

    rp = sub.add_parser("replay", help="replay a request")
    rp.add_argument("capture_dir")
    rp.add_argument("--endpoint", required=True, help='e.g. "GET /api/orders"')
    rp.add_argument("--query", action="append")
    rp.add_argument("--body", action="append")
    rp.add_argument("--header", action="append")
    rp.add_argument("--allow-writes", action="store_true")
    rp.add_argument("--trigger", help="CSS selector for action replay (tier 3)")
    rp.set_defaults(func=cmd_replay)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
