"""Local FastAPI server: serves the assembled session.json and the static 3D
viewer. Self-contained — binds to localhost, no external calls.
"""

from __future__ import annotations

import json
import os

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .export import build_openapi, build_session_json
from .model import Session

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "web")


def _load_doc(capture_dir: str) -> dict:
    sj = os.path.join(capture_dir, "session.json")
    if os.path.exists(sj):
        with open(sj, encoding="utf-8") as fh:
            return json.load(fh)
    har = os.path.join(capture_dir, "session.har")
    return build_session_json(Session.load(har))


def create_app(capture_dir: str) -> FastAPI:
    app = FastAPI(title="spyscan")

    @app.get("/api/session")
    def session_doc():
        return JSONResponse(_load_doc(capture_dir))

    @app.get("/api/openapi")
    def openapi_doc():
        har = os.path.join(capture_dir, "session.har")
        return JSONResponse(build_openapi(Session.load(har)))

    @app.get("/")
    def index():
        return FileResponse(os.path.join(WEB_DIR, "index.html"))

    if os.path.isdir(WEB_DIR):
        app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
    return app
