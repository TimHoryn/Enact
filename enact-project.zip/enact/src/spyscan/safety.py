"""Credential hygiene: a capture holds live cookies/tokens in clear text.
``scrub_capture`` writes redacted copies safe to share, leaving originals intact.
"""

from __future__ import annotations

import json
import os

_RED = "***REDACTED***"


def scrub_capture(capture_dir: str) -> dict:
    counts = {"session_fields": 0, "storage_cookies": 0, "outputs": []}

    sj = os.path.join(capture_dir, "session.json")
    if os.path.exists(sj):
        with open(sj, encoding="utf-8") as fh:
            data = json.load(fh)
        auth = data.get("auth", {})
        for c in (auth.get("cookies") or {}).values():
            if c.get("value"):
                c["value"] = _RED
                counts["session_fields"] += 1
        hdr = auth.get("headers") or {}
        for k in list(hdr):
            hdr[k] = _RED
            counts["session_fields"] += 1
        if auth.get("refresh_token"):
            auth["refresh_token"] = _RED
            counts["session_fields"] += 1
        for t in auth.get("tokens") or []:
            if t.get("preview"):
                t["preview"] = _RED
            t["claims"] = {}
        out = os.path.join(capture_dir, "session.redacted.json")
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        counts["outputs"].append(out)

    ss = os.path.join(capture_dir, "storage_state.json")
    if os.path.exists(ss):
        with open(ss, encoding="utf-8") as fh:
            sd = json.load(fh)
        for c in sd.get("cookies", []):
            if c.get("value"):
                c["value"] = _RED
                counts["storage_cookies"] += 1
        for origin in sd.get("origins", []):
            for item in origin.get("localStorage", []):
                item["value"] = _RED
        out = os.path.join(capture_dir, "storage_state.redacted.json")
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(sd, fh, ensure_ascii=False, indent=2)
        counts["outputs"].append(out)

    return counts
