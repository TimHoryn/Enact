"""Apply edits to a request before replay — any format: query string, JSON
body, form body, GraphQL variables, headers, cookies. Produces a fresh
``ReplayRequest`` and never mutates the input.
"""

from __future__ import annotations

import copy
import json
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .model import ReplayRequest


def _edit_query(url: str, edits: dict[str, Any]) -> str:
    parts = urlparse(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    out: list[tuple[str, str]] = []
    handled: set[str] = set()
    for key, value in pairs:
        if key in edits:
            handled.add(key)
            if edits[key] is None:
                continue  # remove
            out.append((key, str(edits[key])))
        else:
            out.append((key, value))
    # New keys not previously present.
    for key, value in edits.items():
        if key not in handled and value is not None:
            out.append((key, str(value)))
    new_query = urlencode(out)
    return urlunparse(parts._replace(query=new_query))


def _edit_body(body: str | None, body_edits: dict | None, gql_vars: dict | None) -> str | None:
    if body_edits is None and gql_vars is None:
        return body
    data: Any = {}
    if body:
        try:
            data = json.loads(body)
        except Exception:
            # Not JSON: treat as form-encoded.
            form = dict(parse_qsl(body, keep_blank_values=True))
            if body_edits:
                for k, v in body_edits.items():
                    if v is None:
                        form.pop(k, None)
                    else:
                        form[k] = str(v)
            return urlencode(form)
    data = copy.deepcopy(data) if isinstance(data, (dict, list)) else {}
    if body_edits and isinstance(data, dict):
        for k, v in body_edits.items():
            if v is None:
                data.pop(k, None)
            else:
                data[k] = v
    if gql_vars is not None and isinstance(data, dict):
        variables = dict(data.get("variables") or {})
        variables.update(gql_vars)
        data["variables"] = variables
    return json.dumps(data)


def _edit_headers(headers: list[tuple[str, str]], edits: dict | None) -> list[tuple[str, str]]:
    if not edits:
        return list(headers)
    out: list[tuple[str, str]] = []
    handled: set[str] = set()
    lowered = {k.lower(): k for k in edits}
    for name, value in headers:
        low = name.lower()
        if low in lowered:
            handled.add(low)
            new_val = edits[lowered[low]]
            if new_val is None:
                continue  # remove
            out.append((name, str(new_val)))
        else:
            out.append((name, value))
    for low, orig_key in lowered.items():
        if low not in handled and edits[orig_key] is not None:
            out.append((orig_key, str(edits[orig_key])))
    return out


def mutate(request: ReplayRequest, edits: dict[str, Any]) -> ReplayRequest:
    """edits keys: ``query``, ``body``, ``graphql_variables``, ``headers``,
    ``cookies``, ``url``, ``method``. A value of ``None`` removes that field."""
    url = edits.get("url", request.url)
    if "query" in edits:
        url = _edit_query(url, edits["query"])

    cookies = dict(request.cookies)
    for k, v in (edits.get("cookies") or {}).items():
        if v is None:
            cookies.pop(k, None)
        else:
            cookies[k] = str(v)

    return ReplayRequest(
        method=edits.get("method", request.method),
        url=url,
        headers=_edit_headers(request.headers, edits.get("headers")),
        cookies=cookies,
        body=_edit_body(request.body, edits.get("body"), edits.get("graphql_variables")),
    )
