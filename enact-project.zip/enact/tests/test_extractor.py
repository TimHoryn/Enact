from spyscan.extractor import extract_auth


def test_cookies_collected_with_flags(shop_session):
    auth = extract_auth(shop_session)
    assert "session_id" in auth.cookies
    assert "csrftoken" in auth.cookies
    assert auth.cookies["session_id"].secure is True
    assert auth.cookies["session_id"].http_only is True
    # csrftoken was set without Secure/HttpOnly
    assert auth.cookies["csrftoken"].secure is False
    assert auth.cookies["csrftoken"].http_only is False


def test_auth_headers_detected(shop_session):
    auth = extract_auth(shop_session)
    assert auth.auth_headers.get("Authorization", "").startswith("Bearer ")
    assert auth.auth_headers.get("X-CSRF-Token") == "csrf-abc-123"
    # ordinary headers are not treated as auth
    assert "Accept" not in auth.auth_headers


def test_jwt_decoded(shop_session):
    auth = extract_auth(shop_session)
    jwts = [t for t in auth.tokens if t.kind == "jwt"]
    assert jwts, "expected at least one decoded JWT"
    tok = jwts[0]
    assert tok.claims["sub"] == 42
    assert tok.claims["email"] == "user@mail.com"
    assert "exp" in tok.claims


def test_refresh_token_and_lifetime(shop_session):
    auth = extract_auth(shop_session)
    assert auth.refresh_token == "ref-111-222"
    assert auth.token_lifetime == 3600
