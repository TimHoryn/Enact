import json

from spyscan.safety import scrub_capture


def test_scrub_redacts_but_keeps_originals(tmp_path):
    (tmp_path / "session.json").write_text(json.dumps({
        "auth": {
            "cookies": {"session_id": {"value": "sess-secret"}},
            "headers": {"Authorization": "Bearer abc"},
            "refresh_token": "ref-secret",
            "tokens": [{"preview": "eyJ…", "claims": {"sub": 42}}],
        }
    }))
    (tmp_path / "storage_state.json").write_text(json.dumps({
        "cookies": [{"name": "session_id", "value": "sess-secret"}],
        "origins": [{"localStorage": [{"name": "t", "value": "tok"}]}],
    }))
    c = scrub_capture(str(tmp_path))
    assert c["session_fields"] >= 3 and c["storage_cookies"] == 1

    red = json.loads((tmp_path / "session.redacted.json").read_text())
    assert red["auth"]["cookies"]["session_id"]["value"] == "***REDACTED***"
    assert red["auth"]["refresh_token"] == "***REDACTED***"
    assert "Bearer abc" not in json.dumps(red)
    # original untouched
    orig = json.loads((tmp_path / "session.json").read_text())
    assert orig["auth"]["refresh_token"] == "ref-secret"

    sred = json.loads((tmp_path / "storage_state.redacted.json").read_text())
    assert sred["cookies"][0]["value"] == "***REDACTED***"
    assert sred["origins"][0]["localStorage"][0]["value"] == "***REDACTED***"
