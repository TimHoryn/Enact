from spyscan.provenance import analyze_provenance


def _loc(origins, location_substr):
    for vo in origins:
        if location_substr.lower() in vo.location.lower():
            return vo
    raise AssertionError(f"no traced value matching {location_substr!r} in {[v.location for v in origins]}")


def test_session_cookie_from_set_cookie(shop_session):
    rep = analyze_provenance(shop_session)
    origins = rep.for_request(2)  # GET /api/user/profile
    vo = _loc(origins, "cookie session_id")
    assert vo.origin is not None
    assert vo.origin.kind == "set_cookie"
    assert vo.origin.entry_index == 1  # born in the login response
    assert vo.computed is False


def test_bearer_token_from_response_body(shop_session):
    rep = analyze_provenance(shop_session)
    origins = rep.for_request(2)
    vo = _loc(origins, "authorization")
    assert vo.origin is not None
    assert vo.origin.kind == "response_body"
    assert vo.origin.entry_index == 1
    assert "token" in vo.origin.detail


def test_csrf_double_submit_seed(shop_session):
    rep = analyze_provenance(shop_session)
    origins = rep.for_request(4)  # POST /api/cart/add
    vo = _loc(origins, "x-csrf-token")
    assert vo.origin is not None
    # csrf value was seeded upstream (set-cookie or html meta on the login page)
    assert vo.origin.entry_index == 0
    assert vo.origin.kind in ("set_cookie", "html")


def test_one_time_nonce_is_computed(shop_session):
    rep = analyze_provenance(shop_session)
    origins = rep.for_request(4)
    vo = _loc(origins, "x-request-nonce")
    assert vo.origin is None
    assert vo.computed is True  # not found upstream -> produced in-page (JS)


def test_refresh_plan_orders_upstream(shop_session):
    rep = analyze_provenance(shop_session)
    plan = rep.refresh_plan(4)  # to replay cart/add, refresh these first
    # must include the login page (0) and the login POST (1), in order
    assert plan == sorted(set(plan))
    assert 0 in plan and 1 in plan
    assert 4 not in plan


def test_needs_browser_when_computed(shop_session):
    rep = analyze_provenance(shop_session)
    assert rep.needs_browser(4) is True   # nonce is computed
    assert rep.needs_browser(3) is False  # orders: all values traceable
