import os
import shutil

from starlette.testclient import TestClient

from spyscan.server import create_app

FIX = os.path.join(os.path.dirname(__file__), "fixtures", "shop_session.har")


def test_server_serves_session_and_openapi(tmp_path):
    cap = tmp_path / "cap"
    cap.mkdir()
    shutil.copy(FIX, cap / "session.har")
    client = TestClient(create_app(str(cap)))

    r = client.get("/api/session")
    assert r.status_code == 200
    doc = r.json()
    assert doc["_meta"]["tool"] == "spyscan"
    assert doc["graph"]["nodes"]

    r2 = client.get("/api/openapi")
    assert r2.status_code == 200
    assert "/api/orders" in r2.json()["paths"]

    r3 = client.get("/")
    assert r3.status_code == 200
    assert "spyscan" in r3.text.lower()
