from spyscan.model import Session
from spyscan.privacy import audit_privacy


def test_tracker_detected(shop_session):
    rep = audit_privacy(shop_session)
    hosts = {t.host for t in rep.trackers}
    assert any("google-analytics" in h for h in hosts)
    ga = next(t for t in rep.trackers if "google-analytics" in t.host)
    assert ga.category == "analytics"
    assert ga.service == "Google Analytics"


def test_email_leak_to_third_party(shop_session):
    rep = audit_privacy(shop_session)
    email_leaks = [l for l in rep.leaks if l.kind == "email"]
    assert email_leaks, "expected an email leak to the tracker"
    leak = email_leaks[0]
    assert leak.third_party is True
    assert "google-analytics" in leak.to_host
    assert leak.severity == "medium"


def test_first_party_password_not_flagged(shop_session):
    rep = audit_privacy(shop_session)
    # password went to the first-party login endpoint — that is expected, not a leak
    assert not any(l.kind == "password" for l in rep.leaks)


def test_cookie_audit(shop_session):
    rep = audit_privacy(shop_session)
    by_name = {c.name: c for c in rep.cookies}
    assert by_name["session_id"].score == 100
    assert by_name["session_id"].issues == []
    assert by_name["csrftoken"].score < 100
    assert any("secure" in i.lower() for i in by_name["csrftoken"].issues)


def test_secret_in_url_flagged():
    har = {
        "log": {
            "entries": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://api.shop.example.com/data?api_key=AKIAIOSFODNN7EXAMPLE&page=1",
                        "headers": [], "cookies": [],
                        "queryString": [
                            {"name": "api_key", "value": "AKIAIOSFODNN7EXAMPLE"},
                            {"name": "page", "value": "1"},
                        ],
                    },
                    "response": {"status": 200, "headers": [], "cookies": [], "content": {}},
                }
            ]
        }
    }
    rep = audit_privacy(Session.from_har(har))
    assert any(l.kind in ("aws_key", "api_key") and l.severity == "critical" for l in rep.leaks)
    assert any(l.in_url for l in rep.leaks)
