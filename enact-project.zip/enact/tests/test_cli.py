import json
import os
import shutil

from spyscan.cli import main

FIX = os.path.join(os.path.dirname(__file__), "fixtures", "shop_session.har")


def test_analyze_writes_outputs(tmp_path, capsys):
    cap = tmp_path / "cap"
    cap.mkdir()
    shutil.copy(FIX, cap / "session.har")
    rc = main(["analyze", str(cap)])
    assert rc == 0
    assert (cap / "session.json").exists()
    assert (cap / "openapi.json").exists()
    doc = json.loads((cap / "session.json").read_text())
    assert doc["_meta"]["tool"] == "spyscan"
    out = capsys.readouterr().out
    assert "Endpoints" in out


def test_replay_endpoint_not_found(tmp_path):
    cap = tmp_path / "cap"
    cap.mkdir()
    shutil.copy(FIX, cap / "session.har")
    rc = main(["replay", str(cap), "--endpoint", "GET /nope"])
    assert rc == 1
