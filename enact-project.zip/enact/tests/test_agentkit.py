from spyscan.agentkit import build_manifest, build_tool_schemas
from spyscan.export import build_session_json


def test_manifest(shop_session):
    man = build_manifest(build_session_json(shop_session))
    assert man["tool"] == "spyscan"
    paths = {o["path"] for o in man["operations"]}
    assert "/api/orders" in paths
    orders = next(o for o in man["operations"] if o["path"] == "/api/orders")
    assert any(p["name"] == "status" for p in orders["params"])
    assert "sp.call" in orders["example_call"]
    assert "rules" in man and man["operations"]


def test_tool_schemas(shop_session):
    tools = build_tool_schemas(build_session_json(shop_session))
    assert tools
    assert all({"name", "description", "input_schema"} <= set(t) for t in tools)
    orders = next(t for t in tools if "orders" in t["name"])
    assert "page" in orders["input_schema"]["properties"]
    assert orders["input_schema"]["properties"]["page"]["type"] == "integer"
