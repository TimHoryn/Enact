from spyscan.export import build_openapi, build_session_json


def test_session_json_shape(shop_session):
    doc = build_session_json(shop_session)
    assert doc["_meta"]["tool"] == "spyscan"
    assert "shop.example.com" in doc["_meta"]["site"]
    assert "session_id" in doc["auth"]["cookies"]
    assert doc["auth"]["refresh_token"] == "ref-111-222"


def test_replay_recipe(shop_session):
    doc = build_session_json(shop_session)
    recipe = {r["endpoint"]: r for r in doc["replay_recipe"]}
    orders = recipe["GET /api/orders"]
    assert orders["needs_auth"] is True
    names = {p["name"] for p in orders["editable_params"]}
    assert {"status", "page"} <= names
    cart = recipe["POST /api/cart/add"]
    assert cart["needs_csrf"] is True
    assert cart["refresh_plan"]  # upstream to refresh before replay


def test_privacy_and_token_flow(shop_session):
    doc = build_session_json(shop_session)
    assert any("google-analytics" in t["host"] for t in doc["privacy"]["trackers"])
    assert any(l["kind"] == "email" for l in doc["privacy"]["leaks"])
    assert any(t["kind"] == "jwt" for t in doc["token_flow"])


def test_graph_nodes_and_links(shop_session):
    doc = build_session_json(shop_session)
    nodes = doc["graph"]["nodes"]
    kinds = {n["type"] for n in nodes}
    assert "site" in kinds and "tracker" in kinds
    # host nodes carry a request count
    assert all("count" in n for n in nodes)
    assert any(l["type"] == "leak" for l in doc["graph"]["links"])
    assert any(l["type"] in ("flow", "tracker") for l in doc["graph"]["links"])


def test_api_map(shop_session):
    doc = build_session_json(shop_session)
    amap = doc["api_map"]
    assert "shop.example.com" in amap
    paths = {e["path"] for e in amap["shop.example.com"]}
    assert "/api/orders" in paths
    orders = next(e for e in amap["shop.example.com"] if e["path"] == "/api/orders")
    assert "orders" in orders["returns"]  # shape of the JSON body
    assert any(p["name"] == "status" for p in orders["params"])


def test_params_catalog(shop_session):
    doc = build_session_json(shop_session)
    cat = doc["params_catalog"]
    assert any(it["name"] == "page" for it in cat.get("pagination", []))
    assert any(it["name"] == "status" for it in cat.get("filter", []))


def test_recipe_returns_shape(shop_session):
    doc = build_session_json(shop_session)
    rec = {r["endpoint"]: r for r in doc["replay_recipe"]}
    assert "orders" in rec["GET /api/orders"]["returns"]


def test_agent_and_human_markdown(shop_session):
    from spyscan.docgen import build_agent_markdown, build_human_markdown
    doc = build_session_json(shop_session)
    agent = build_agent_markdown(doc)
    human = build_human_markdown(doc)
    assert "Available requests" in agent and "/api/orders" in agent
    assert "eng.replay" in agent
    assert "Request map" in human and "shop.example.com" in human


def test_tasks(shop_session):
    doc = build_session_json(shop_session)
    tasks = doc["tasks"]
    assert any(t["kind"] == "collect" for t in tasks)  # orders is paginated
    assert any(t["kind"] == "write" for t in tasks)    # cart POST
    collect = next(t for t in tasks if t["kind"] == "collect")
    assert "spyscan collect" in collect["command"]


def test_openapi(shop_session):
    spec = build_openapi(shop_session)
    assert spec["openapi"].startswith("3.")
    assert "/api/orders" in spec["paths"]
    assert "get" in spec["paths"]["/api/orders"]
