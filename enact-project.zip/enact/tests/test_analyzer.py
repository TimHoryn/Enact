from spyscan.analyzer import analyze
from spyscan.model import Session


def _ep(analysis, path):
    for e in analysis.endpoints:
        if e.path == path:
            return e
    raise AssertionError(f"endpoint {path} not found")


def test_editable_params_classified(shop_session):
    a = analyze(shop_session)
    orders = _ep(a, "/api/orders")
    params = {p.name: p for p in orders.editable_params}
    assert params["status"].type == "filter"
    assert params["page"].type == "pagination"
    assert params["page"].where == "query"


def test_body_params_and_csrf(shop_session):
    a = analyze(shop_session)
    cart = _ep(a, "/api/cart/add")
    params = {p.name: p for p in cart.editable_params}
    assert params["product_id"].type == "identifier"
    assert params["quantity"].where == "body"
    assert cart.needs_csrf is True
    assert cart.needs_auth is True


def test_secrets_not_offered_as_editable(shop_session):
    a = analyze(shop_session)
    login = _ep(a, "/api/auth/login")
    names = {p.name for p in login.editable_params}
    assert "password" not in names
    assert login.needs_auth is False  # login establishes auth, doesn't need it


def test_token_flow(shop_session):
    a = analyze(shop_session)
    assert a.token_flow, "expected token flow"
    jwt = next(t for t in a.token_flow if t.kind == "jwt")
    assert "/api/auth/login" in jwt.born_at
    used_paths = " ".join(jwt.used_in)
    assert "/api/user/profile" in used_paths
    assert "/api/orders" in used_paths


def test_no_blockers_in_clean_fixture(shop_session):
    a = analyze(shop_session)
    assert a.blockers == []


def test_captcha_blocker_detected():
    har = {
        "log": {
            "entries": [
                {
                    "request": {"method": "POST", "url": "https://x.example.com/checkout", "headers": [], "cookies": []},
                    "response": {
                        "status": 200,
                        "headers": [{"name": "Content-Type", "value": "text/html"}],
                        "cookies": [],
                        "content": {"mimeType": "text/html", "text": "<div class='g-recaptcha' data-sitekey='abc'></div>"},
                    },
                }
            ]
        }
    }
    a = analyze(Session.from_har(har))
    assert any(b.type == "captcha" for b in a.blockers)
    cap = next(b for b in a.blockers if b.type == "captcha")
    assert cap.bypass is False
    assert "recaptcha" in cap.service.lower()
