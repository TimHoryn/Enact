import os

import pytest

from spyscan.model import Session

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


@pytest.fixture
def shop_session() -> Session:
    return Session.load(os.path.join(FIXTURES, "shop_session.har"))
