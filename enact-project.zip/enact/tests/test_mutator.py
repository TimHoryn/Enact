import json

from spyscan.model import ReplayRequest
from spyscan.mutator import mutate


def _rr_get():
    return ReplayRequest(
        method="GET",
        url="https://shop.example.com/api/orders?status=active&page=1",
        headers=[("Authorization", "Bearer x")],
        cookies={"session_id": "s"},
    )


def _rr_post(body):
    return ReplayRequest(
        method="POST",
        url="https://shop.example.com/api/cart/add",
        headers=[("Content-Type", "application/json")],
        cookies={"session_id": "s"},
        body=json.dumps(body),
    )


def test_query_edit():
    out = mutate(_rr_get(), {"query": {"page": 2, "status": "all"}})
    assert "page=2" in out.url
    assert "status=all" in out.url
    assert "status=active" not in out.url


def test_query_remove():
    out = mutate(_rr_get(), {"query": {"page": None}})
    assert "page=" not in out.url
    assert "status=active" in out.url


def test_body_json_merge():
    out = mutate(_rr_post({"product_id": 55, "quantity": 1}), {"body": {"product_id": 99}})
    data = json.loads(out.body)
    assert data == {"product_id": 99, "quantity": 1}


def test_graphql_variables_merge():
    gql = {"query": "query($id:ID!){item(id:$id){name}}", "variables": {"id": "1"}}
    out = mutate(_rr_post(gql), {"graphql_variables": {"id": "42"}})
    data = json.loads(out.body)
    assert data["variables"]["id"] == "42"
    assert data["query"].startswith("query")


def test_header_and_cookie_edit():
    out = mutate(_rr_get(), {"headers": {"X-Trace": "1"}, "cookies": {"session_id": "new"}})
    assert out.header("X-Trace") == "1"
    assert out.cookies["session_id"] == "new"


def test_original_untouched():
    rr = _rr_post({"product_id": 55})
    mutate(rr, {"body": {"product_id": 1}})
    assert json.loads(rr.body) == {"product_id": 55}
