from spyscan.model import Session


def test_parses_all_entries(shop_session: Session):
    assert len(shop_session.entries) == 6
    assert shop_session.meta["creator"] == "spyscan-test-fixture"


def test_request_fields(shop_session: Session):
    login = shop_session.entries[1]
    assert login.request.method == "POST"
    assert login.request.path == "/api/auth/login"
    assert login.request.is_write
    assert login.request.post_json == {"email": "user@mail.com", "password": "hunter2"}
    assert login.request.headers.get("x-csrf-token") == "csrf-abc-123"
    assert login.request.origin == "https://shop.example.com"


def test_response_fields(shop_session: Session):
    login = shop_session.entries[1]
    assert login.response.status == 200
    assert login.response.body_json["token"].startswith("eyJ")
    cookies = {c.name: c for c in login.response.set_cookies}
    assert cookies["session_id"].secure is True
    assert cookies["session_id"].http_only is True


def test_query_parsing(shop_session: Session):
    orders = shop_session.entries[3]
    assert orders.request.query == {"status": ["active"], "page": ["1"]}


def test_header_order_preserved(shop_session: Session):
    cart = shop_session.entries[4]
    names = cart.request.headers.names()
    assert names.index("Content-Type") < names.index("X-CSRF-Token")


def test_before_returns_upstream(shop_session: Session):
    assert [e.index for e in shop_session.before(3)] == [0, 1, 2]
