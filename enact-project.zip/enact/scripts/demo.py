"""Full-product demo against the bundled local target — no external site needed.

    python scripts/demo.py            # record + analyze + replay, print summary
    python scripts/demo.py --serve    # also launch the 3D viewer on :8088

Spins up the test target in-process, records a real browser session, assembles
session.json, and demonstrates replay of a GET (mutated) and two writes
(one-time nonce + JS signature).
"""

from __future__ import annotations

import os
import socket
import sys
import threading
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from spyscan.browser import BrowserSession          # noqa: E402
from spyscan.cli import main as cli_main             # noqa: E402
from spyscan.model import Session                    # noqa: E402
from spyscan.replay import ReplayEngine              # noqa: E402


def free_port() -> int:
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def start_target() -> str:
    import uvicorn
    from tests.target.app import app
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    return f"http://127.0.0.1:{port}"


def record(base: str, out: str) -> None:
    os.makedirs(out, exist_ok=True)
    sess = BrowserSession(har_path=os.path.join(out, "session.har"),
                          record_actions=True, headless=True, start_url=base + "/login").start()
    page = sess.page
    page.fill('input[name="email"]', "user@mail.com")
    page.fill('input[name="password"]', "hunter2")
    with page.expect_response(lambda r: "/api/auth/login" in r.url):
        page.click("#login > button")
    for sel, path in [("#profile", "/api/user/profile"), ("#orders", "/api/orders"),
                      ("#cart", "/api/cart/add"), ("#place", "/api/order/place")]:
        with page.expect_response(lambda r, p=path: p in r.url):
            page.click(sel)
        time.sleep(0.1)
    sess.save_storage(os.path.join(out, "storage_state.json"))
    sess.stop()


def demo_replays(out: str, base: str) -> None:
    session = Session.load(os.path.join(out, "session.har"))
    sess = BrowserSession(storage_state=os.path.join(out, "storage_state.json"),
                          headless=True, start_url=base + "/login").start()
    try:
        engine = ReplayEngine(sess, session, allow_writes=False)
        idx = lambda p: next(e.index for e in session.entries if e.request.path == p)

        r = engine.replay(idx("/api/orders"), edits={"query": {"page": 2}})
        print(f"  GET /api/orders?page=2  → tier={r.tier} status={r.status}")

        r = engine.replay(idx("/api/cart/add"))
        print(f"  POST /api/cart/add (dry-run) → dry_run={r.dry_run} (not sent)")

        r = engine.replay(idx("/api/cart/add"), edits={"body": {"product_id": 99}}, allow_writes=True)
        print(f"  POST /api/cart/add (allow-writes, fresh nonce) → status={r.status} refreshed={len(r.refreshed or {})}")

        r = engine.replay(idx("/api/order/place"), allow_writes=True, trigger_selector="#place")
        print(f"  POST /api/order/place (JS signature, action replay) → tier={r.tier} status={r.status}")
    finally:
        sess.stop()


def main() -> int:
    out = os.path.join(os.path.dirname(__file__), "..", "capture_demo")
    base = start_target()
    print(f"Target: {base}")
    print("1) Recording a session via the browser…")
    record(base, out)
    print("2) Analyze…")
    cli_main(["analyze", out])
    print("3) Replaying requests:")
    demo_replays(out, base)
    if "--serve" in sys.argv:
        print("4) 3D visualization:")
        cli_main(["serve", out, "--port", "8088"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
